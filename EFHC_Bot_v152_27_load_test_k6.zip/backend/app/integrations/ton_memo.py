# ======================================================================
# КАНОН MEMO для входящих платежей TON/USDT/EFHC.
#
# Форматы:
# 1) Депозит EFHC: EFHC:<tg_id>
# 2) Покупка EFHC-пакета: BUY:EFHC:<qty>:TG:<tg_id>[:OID:<order_id>]
#
# Назначение:
# - watcher: распознаёт MEMO и выполняет автозачисление.
# - shop/bot: строят корректный MEMO для оплаты.
# ======================================================================

from __future__ import annotations

import re
from dataclasses import dataclass

# ----------------------------------------------------------------------
# Регулярные выражения канона MEMO.
# ----------------------------------------------------------------------
# 1) ДЕПОЗИТ EFHC: "EFHC:<tg_id>"
_RE_DEPOSIT = re.compile(r"^EFHC:(?P<tg_id>\d{3,20})$")

# 2) ПОКУПКА EFHC-ПАКЕТА: "BUY:EFHC:<qty>:TG:<tg_id>[:OID:<order_id>]"
# - qty: целое число, минимум 1
# - tg_id: 3..20 цифр
# - order_id (опционально): буквы/цифры/дефис/подчёркивание,
#   до 64 символов
_BUY_PACK_RE = (
    r"^BUY:EFHC:"
    r"(?P<qty>[1-9]\d*):TG:"
    r"(?P<tg_id>\d{3,20})"
    r"(?::OID:(?P<oid>[A-Za-z0-9\-_]{1,64}))?$"
)
_RE_BUY_PACK = re.compile(_BUY_PACK_RE)

# ----------------------------------------------------------------------
# Результаты парсинга.
# ----------------------------------------------------------------------
@dataclass(frozen=True)

class MemoDepositEFHC:
    """Депозит EFHC.

    Сумма берётся из транзакции EFHC на адрес проекта.
    """
    tg_id: int

@dataclass(frozen=True)
class MemoBuyEFHCPack:
    """Покупка EFHC-пакета за TON/USDT. Количество задано в MEMO."""
    tg_id: int
    qty_efhc: int
    order_id: str | None = None


MemoParsed = MemoDepositEFHC | MemoBuyEFHCPack


# ----------------------------------------------------------------------
# Генераторы MEMO (использует Shop/бот)
# ----------------------------------------------------------------------


def build_deposit_memo(tg_id: int) -> str:
    """
    Создаёт MEMO для депозита EFHC: 'EFHC:<tg_id>'.
    Пример: EFHC:362746228
    """
    if tg_id <= 0:
        raise ValueError("tg_id должен быть положительным целым.")
    return f"EFHC:{tg_id}"

def build_buy_pack_memo(
    tg_id: int,
    qty_efhc: int,
    order_id: str | None = None,
) -> str:
    """
    Создаёт MEMO: 'BUY:EFHC:<qty>:TG:<tg_id>[:OID:<order_id>]'.
    • qty_efhc — СКОЛЬКО EFHC нужно начислить (строго целое число >= 1).
    • order_id — опционально; связывает заказ в БД с транзакцией.
    """
    if tg_id <= 0:
        raise ValueError("tg_id должен быть положительным целым.")
    if qty_efhc < 1:
        raise ValueError("qty_efhc должен быть целым числом >= 1.")
    base = f"BUY:EFHC:{qty_efhc}:TG:{tg_id}"
    if order_id:
        return f"{base}:OID:{order_id}"
    return base

# ----------------------------------------------------------------------
# Парсер MEMO (использует watcher_service)
# ----------------------------------------------------------------------


def parse_memo(memo: str | None) -> MemoParsed | None:
    """
    Разбирает строку MEMO и возвращает структуру с данными.
    Возвращает None, если MEMO не соответствует канону.
    """
    if memo is None:
        return None

    s = memo.strip()

    # 1) депозит EFHC
    m = _RE_DEPOSIT.match(s)
    if m:
        return MemoDepositEFHC(tg_id=int(m.group("tg_id")))

    # 2) покупка EFHC-пакета
    m = _RE_BUY_PACK.match(s)
    if m:
        tg_id = int(m.group("tg_id"))
        qty = int(m.group("qty"))
        oid = m.group("oid")
        return MemoBuyEFHCPack(
            tg_id=tg_id,
            qty_efhc=qty,
            order_id=oid,
        )

    return None

# ----------------------------------------------------------------------
# Быстрые примеры (для разработчиков)
# ----------------------------------------------------------------------
# build_deposit_memo(362746228)  -> "EFHC:362746228"
# parse_memo("EFHC:362746228")   -> MemoDepositEFHC(tg_id=362746228)
#
# build_buy_pack_memo(362746228, 100) ->
# "BUY:EFHC:100:TG:362746228"
# build_buy_pack_memo(362746228, 100, "ORD-123") ->
# "BUY:EFHC:100:TG:362746228:OID:ORD-123"
# parse_memo("BUY:EFHC:100:TG:362746228") ->
# MemoBuyEFHCPack(tg_id=362746228, qty_efhc=100)
# parse_memo("BUY:EFHC:250:TG:362746228:OID:ORD-123") ->
# MemoBuyEFHCPack(tg_id=362746228, qty_efhc=250, order_id="ORD-123")

