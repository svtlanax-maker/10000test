"""Deprecated module.

This file exists only for repo integrity baseline.
Do not import it in EFHC Bot.
Use app.core.database_core instead.
"""

from __future__ import annotations

from app.core.database_core import (  # noqa: F401
    get_engine,
    get_session_factory,
)
