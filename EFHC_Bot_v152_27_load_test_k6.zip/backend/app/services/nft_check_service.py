# backend/app/services/nft_check_service.py
# ======================================================================
# Проверка VIP по наличию NFT из канонической TON-коллекции в кошельке
# пользователя (users.ton_wallet). Денежные операции не выполняются.
#
# Канон:
# - VIP = факт наличия NFT из TON_NFT_COLLECTION.
# - Авто-минтинг запрещён. Shop/покупка — отдельный процесс.
#
# Таблицы кэша/логов опциональны. Если их нет — сервис работает без них.
# ======================================================================

from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass
from datetime import datetime, timedelta
from typing import Any

from app.core.config_core import get_settings
from app.core.database_core import get_session_factory
from app.core.logging_core import get_logger
from app.core.sql_aliases_core import canon_admin_table, canon_schema
from pydantic import BaseModel, Field
from sqlalchemy import text
from sqlalchemy.engine import Result
from sqlalchemy.ext.asyncio import AsyncSession

logger = get_logger(__name__)
S = get_settings()


# ======================================================================
# Конфигурация (.env)
# ======================================================================

SCHEMA_CORE: str = canon_schema(
    getattr(S, "DB_SCHEMA_CORE", "efhc_core")
    or "efhc_core",
)
SCHEMA_ADMIN: str = (
    getattr(S, "DB_SCHEMA_ADMIN", SCHEMA_CORE) or SCHEMA_CORE
)

_TON_API_DEFAULT = "https://tonapi.io/v2"
TON_API_BASE: str = str(getattr(S, "TON_API_URL", _TON_API_DEFAULT)
                        or _TON_API_DEFAULT)
TON_API_KEY: str = str(getattr(S, "TON_API_KEY", "") or "")

TON_NFT_COLLECTION: str = str(
    getattr(
        S,
        "TON_NFT_COLLECTION",
        getattr(S, "GETGEMS_COLLECTION", ""),
    )
    or ""
)

# TTL кэша (сек)
NFT_CACHE_TTL_SECONDS: int = int(
    getattr(S, "NFT_CACHE_TTL_SECONDS", 900) or 900
)

# Размер батча
VIP_CHECK_BATCH_SIZE: int = int(
    getattr(S, "NFT_CHECK_BATCH_SIZE", 500) or 500
)


# ======================================================================
# DTO
# ======================================================================


class NftAsset(BaseModel):
    """Упрощённое описание NFT из коллекции TON."""

    collection_address: str
    token_id: str
    name: str | None = None
    raw: dict[str, Any] | None = None


class NftCheckResult(BaseModel):
    """Результат проверки VIP для пользователя."""

    tg_id: int
    ton_wallet: str
    is_vip: bool
    vip_assets: list[NftAsset] = Field(default_factory=list)
    all_assets: list[NftAsset] = Field(default_factory=list)
    checked_at: datetime = Field(default_factory=datetime.utcnow)
    source: str = Field(default="LIVE", description="LIVE | CACHE")


class NftCheckError(RuntimeError):
    """Ошибка сервиса проверки NFT/VIP."""


@dataclass
class VipBatchStats:
    total: int
    changed: int


# ======================================================================
# HTTP helper (динамический импорт httpx)
# ======================================================================


async def _http_get_json(
    url: str,
    headers: dict[str, str] | None = None,
    params: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """GET → JSON. Если httpx отсутствует — поднимаем NftCheckError."""
    try:
        import httpx  # type: ignore
    except Exception as exc:  # noqa: BLE001
        msg = (
            "Зависимость httpx не установлена. Добавьте "
            "'httpx[http2]' в зависимости."
        )
        raise NftCheckError(msg) from exc

    try:
        async with httpx.AsyncClient(
            timeout=15.0,
            http2=True,
        ) as client:
            r = await client.get(url, headers=headers, params=params)
            r.raise_for_status()
            return r.json()  # type: ignore[no-any-return]
    except Exception as exc:  # noqa: BLE001
        raise NftCheckError(f"Ошибка TON API: {exc}") from exc


# ======================================================================
# Кэш efhc_admin.nft_check_cache_ton (опционально)
# ======================================================================


class _Cache:
    @staticmethod
    async def _table_exists(db: AsyncSession) -> bool:
        """True, если таблица кэша существует."""
        sql = text(
            """
            SELECT 1
            FROM information_schema.tables
            WHERE table_schema = :schema
              AND table_name = :table
            LIMIT 1
            """
        )
        r: Result = await db.execute(
            sql,
            {
                "schema": SCHEMA_ADMIN,
                "table": "nft_check_cache_ton",
            },
        )
        return r.fetchone() is not None

    @staticmethod
    async def try_read(
        db: AsyncSession,
        address: str,
    ) -> list[dict[str, Any]] | None:
        """Вернуть кэш, если он не просрочен; иначе None."""
        if not await _Cache._table_exists(db):
            return None

        min_ts = datetime.utcnow() - timedelta(
            seconds=NFT_CACHE_TTL_SECONDS,
        )
        sql = text("""
            SELECT assets_json 
            FROM efhc_admin.nft_check_cache_ton
            WHERE address = :addr
              AND snapshot_at >= :min_ts
            LIMIT 1
            """
        )
        r: Result = await db.execute(
            sql,
            {
                "addr": address,
                "min_ts": min_ts,
            },
        )
        row = r.fetchone()
        if not row:
            return None
        assets = row.assets_json  # type: ignore[attr-defined]
        return assets  # type: ignore[no-any-return]

    @staticmethod
    async def write(
        db: AsyncSession,
        address: str,
        assets_json: list[dict[str, Any]],
    ) -> None:
        """Записать/обновить кэш. Если таблицы нет — пропустить."""
        if not await _Cache._table_exists(db):
            return

        sql = text("""
            INSERT INTO efhc_admin.nft_check_cache_ton (
                address, 
                assets_json,
                snapshot_at
            )
            VALUES (
                :addr,
                CAST(:assets AS jsonb),
                NOW() AT TIME ZONE 'UTC'
            )
            ON CONFLICT (address) DO UPDATE
            SET assets_json = EXCLUDED.assets_json,
                snapshot_at = EXCLUDED.snapshot_at
            """
        )
        await db.execute(
            sql,
            {
                "addr": address,
                "assets": _json_dumps(assets_json),
            },
        )


# ======================================================================
# Основной сервис проверки NFT/VIP
# ======================================================================


class NftCheckService:
    """VIP проверки и массовая синхронизация users.is_vip."""

    @staticmethod
    async def get_wallet_for_user(
        db: AsyncSession,
        tg_id: int,
    ) -> str | None:
        """Вернуть users.ton_wallet для пользователя tg_id."""
        sql = text("""
            SELECT ton_wallet
            FROM efhc_core.users
            WHERE tg_id = :tg_id 
            LIMIT 1
            """
        )
        r: Result = await db.execute(sql, {"tg_id": tg_id})
        row = r.fetchone()
        if not row or not getattr(row, "ton_wallet", None):
            return None
        wallet = str(row.ton_wallet).strip()
        # type: ignore[attr-defined]
        return wallet or None

    @staticmethod
    async def check_user_vip(
        db: AsyncSession,
        tg_id: int,
        force_refresh: bool = False,
    ) -> NftCheckResult | None:
        """Проверить VIP по TON API/кэшу. БД не изменяет."""
        wallet = await NftCheckService.get_wallet_for_user(db, tg_id)
        if not wallet:
            return None

        source = "LIVE"
        all_assets: list[NftAsset]

        if not force_refresh:
            cached = await _Cache.try_read(db, wallet)
            if cached is not None:
                try:
                    all_assets = [
                        NftAsset(**a) for a in cached
                    ]  # type: ignore[list-item]
                    source = "CACHE"
                except Exception:  # noqa: BLE001
                    all_assets = await _fetch_ton_assets(wallet)
                    await _Cache.write(
                        db,
                        wallet,
                        [a.dict() for a in all_assets],
                    )
            else:
                all_assets = await _fetch_ton_assets(wallet)
                await _Cache.write(
                    db,
                    wallet,
                    [a.dict() for a in all_assets],
                )
        else:
            all_assets = await _fetch_ton_assets(wallet)
            await _Cache.write(
                db,
                wallet,
                [a.dict() for a in all_assets],
            )

        vip_assets = _filter_vip_assets(all_assets, TON_NFT_COLLECTION)
        is_vip = bool(vip_assets)
        return NftCheckResult(
            tg_id=tg_id,
            ton_wallet=wallet,
            is_vip=is_vip,
            vip_assets=vip_assets,
            all_assets=all_assets,
            checked_at=datetime.utcnow(),
            source=source,
        )

    @staticmethod
    async def sync_users_is_vip(
        db: AsyncSession,
        tg_ids: Sequence[int],
        force_refresh: bool = False,
        log_table: str = "vip_status_log",
    ) -> dict[int, bool]:
        """Массово синхронизировать users.is_vip по списку tg_id."""
        out: dict[int, bool] = {}
        for tg_id in tg_ids:
            try:
                res = await NftCheckService.check_user_vip(
                    db,
                    tg_id,
                    force_refresh=force_refresh,
                )
                if res is None:
                    before = await _read_users_is_vip(db, tg_id)
                    updated = await _write_users_is_vip(
                        db,
                        tg_id,
                        False,
                    )
                    out[tg_id] = False
                    changed = (
                        updated and before is not None
                        and before is not False
                    )
                    if changed:
                        await _try_write_vip_log(
                            db,
                            tg_id,
                            old=before,
                            new=False,
                            table=log_table,
                        )
                    continue

                before = await _read_users_is_vip(db, tg_id)
                updated = await _write_users_is_vip(
                    db,
                    tg_id,
                    res.is_vip,
                )
                out[tg_id] = res.is_vip
                changed = (
                    updated and before is not None
                    and before != res.is_vip
                )
                if changed:
                    await _try_write_vip_log(
                        db,
                        tg_id,
                        old=before,
                        new=res.is_vip,
                        table=log_table,
                    )
            except NftCheckError as exc:
                logger.warning(
                    "VIP check failed for tg_id=%s: %s",
                    tg_id,
                    exc,
                )
            except Exception as exc:  # noqa: BLE001
                logger.exception(
                    "VIP check unexpected error for tg_id=%s: %s",
                    tg_id,
                    exc,
                )
        return out


# ======================================================================
# Вспомогательные функции (SQL/TON API)
# ======================================================================


async def _fetch_ton_assets(address: str) -> list[NftAsset]:
    """Забрать NFT-активы для TON-адреса и нормализовать."""
    if not TON_NFT_COLLECTION:
        logger.warning(
            "TON_NFT_COLLECTION не задан — VIP будет всегда False."
        )

    base = TON_API_BASE.rstrip("/")
    url = f"{base}/accounts/{address}/nfts"

    headers: dict[str, str] = {}
    if TON_API_KEY:
        headers["Authorization"] = f"Bearer {TON_API_KEY}"

    params: dict[str, Any] = {"limit": 1000}
    data = await _http_get_json(url, headers=headers, params=params)

    items = data.get("nft_items") or data.get("nfts") or []
    out: list[NftAsset] = []

    for item in items:
        if not isinstance(item, dict):
            continue

        collection_obj = item.get("collection") or {}
        collection_addr = ""
        if isinstance(collection_obj, dict):
            collection_addr = str(collection_obj.get("address") or "")
        if not collection_addr:
            collection_addr = str(item.get("collection_address") or "")

        token_id = str(
            item.get("index")
            or item.get("id")
            or item.get("token_id")
            or ""
        )

        md = item.get("metadata")
        name = md.get("name") if isinstance(md, dict) else None
        if not isinstance(name, str):
            name = None

        if not collection_addr or not token_id:
            continue

        out.append(
            NftAsset(
                collection_address=collection_addr,
                token_id=token_id,
                name=name,
                raw=item,
            )
        )

    return out


def _filter_vip_assets(
    assets: list[NftAsset],
    vip_collection: str,
) -> list[NftAsset]:
    """Фильтр по адресу целевой коллекции."""
    if not vip_collection:
        return []
    return [a for a in assets if a.collection_address == vip_collection]


def _json_dumps(obj: Any) -> str:
    """Безопасный json.dumps для записи в БД."""
    try:
        import json

        return json.dumps(
            obj,
            ensure_ascii=False,
            separators=(",", ":"),
        )
    except Exception:  # noqa: BLE001
        return str(obj)


async def _read_users_is_vip(
    db: AsyncSession,
    tg_id: int,
) -> bool | None:
    """Прочитать users.is_vip для tg_id."""
    sql = text("""
        SELECT is_vip
        FROM efhc_core.users
        WHERE tg_id = :tg_id
        LIMIT 1 
        """
    )
    r: Result = await db.execute(sql, {"tg_id": tg_id})
    row = r.fetchone()
    if not row or getattr(row, "is_vip", None) is None:
        return None
    return bool(row.is_vip)  # type: ignore[attr-defined]


async def _write_users_is_vip(
    db: AsyncSession,
    tg_id: int,
    flag: bool,
) -> bool:
    """Обновить users.is_vip/vip_since/vip_checked_at для tg_id."""
    # nosec B608: static trusted SQL, no user input
    sql = text("""
        UPDATE efhc_core.users
           SET is_vip = :flag,
               vip_since = CASE
                   WHEN :flag = TRUE
                        AND (vip_since IS NULL OR is_vip = FALSE)
                   THEN NOW() AT TIME ZONE 'UTC'
                   WHEN :flag = FALSE
                   THEN NULL
                   ELSE vip_since
               END,
               vip_checked_at = NOW() AT TIME ZONE 'UTC',
               updated_at = NOW() AT TIME ZONE 'UTC'
         WHERE tg_id = :tg_id
        """
    )
    r: Result = await db.execute(
        sql,
        {"tg_id": tg_id, "flag": flag},
    )
    return bool(getattr(r, "rowcount", 0) > 0)


async def _try_write_vip_log(
    db: AsyncSession,
    tg_id: int,
    old: bool | None,
    new: bool,
    table: str = "vip_status_log",
) -> None:
    """Записать лог изменения VIP, если таблица существует."""
    table = canon_admin_table(table)
    exists_sql = text(
        """
        SELECT 1
        FROM information_schema.tables
        WHERE table_schema = :schema
          AND table_name = :table
        LIMIT 1
        """
    )
    r: Result = await db.execute(
        exists_sql,
        {"schema": SCHEMA_ADMIN, "table": table},
    )
    if r.fetchone() is None:
        return

    insert_sql = text("""
        INSERT INTO efhc_admin.{table} (
            tg_id,
            old_flag,
            new_flag,
            created_at
        ) 
        VALUES (
            :tg_id,
            :old,
            :new,
            NOW() AT TIME ZONE 'UTC'
        )
        """
    )
    await db.execute(
        insert_sql,
        {"tg_id": tg_id, "old": old, "new": new},
    )


# ======================================================================
# High-level сценарии
# ======================================================================


async def _fetch_tg_ids_with_wallet_batch(
    db: AsyncSession,
    *,
    offset: int,
    limit: int,
) -> list[int]:
    """Получить батч tg_id с заполненным ton_wallet."""
    sql = text("""
        SELECT tg_id
        FROM efhc_core.users
        WHERE ton_wallet IS NOT NULL
          AND LENGTH(TRIM(ton_wallet)) > 0
        ORDER BY tg_id ASC
        OFFSET :off
        LIMIT :lim 
        """
    )
    r: Result = await db.execute(
        sql,
        {"off": int(offset), "lim": int(limit)},
    )
    rows = r.fetchall()
    tg_ids = [int(row.tg_id) for row in rows]
    # type: ignore[attr-defined]
    return tg_ids


async def check_user_vip_once(
    db: AsyncSession,
    *,
    tg_id: int,
    force_refresh: bool = False,
) -> NftCheckResult | None:
    """Проверить и синхронизировать одного пользователя."""
    try:
        res = await NftCheckService.check_user_vip(
            db,
            tg_id,
            force_refresh=force_refresh,
        )
    except NftCheckError as exc:
        logger.warning(
            "check_user_vip_once: external error for tg_id=%s: %s",
            tg_id,
            exc,
        )
        return None
    except Exception as exc:  # noqa: BLE001
        logger.exception(
            "check_user_vip_once: unexpected error for tg_id=%s: %s",
            tg_id,
            exc,
        )
        return None

    if res is None:
        before = await _read_users_is_vip(db, tg_id)
        updated = await _write_users_is_vip(db, tg_id, False)
        if updated and before is not None and before is not False:
            await _try_write_vip_log(db, tg_id, old=before, new=False)
        return None

    before = await _read_users_is_vip(db, tg_id)
    updated = await _write_users_is_vip(db, tg_id, res.is_vip)
    if updated and before is not None and before != res.is_vip:
        await _try_write_vip_log(db, tg_id, old=before, new=res.is_vip)
    return res


async def check_users_subset(
    db: AsyncSession,
    *,
    tg_ids: list[int],
    force_refresh: bool = False,
) -> VipBatchStats:
    """Проверить список пользователей и посчитать изменения is_vip."""
    if not tg_ids:
        return VipBatchStats(total=0, changed=0)

    total = 0
    changed = 0

    for tg_id in tg_ids:
        before = await _read_users_is_vip(db, tg_id)
        res = await check_user_vip_once(
            db,
            tg_id=tg_id,
            force_refresh=force_refresh,
        )
        total += 1
        if before is None or res is None:
            continue
        after = await _read_users_is_vip(db, tg_id)
        if after is not None and before != after:
            changed += 1

    return VipBatchStats(total=total, changed=changed)


async def check_all_users_once(
    db: AsyncSession,
    *,
    batch_size: int = VIP_CHECK_BATCH_SIZE,
    force_refresh: bool = False,
) -> dict[str, Any]:
    """Массовая проверка всех пользователей с ton_wallet (батчами)."""
    offset = 0
    total = 0
    changed_total = 0
    batches = 0

    while True:
        ids = await _fetch_tg_ids_with_wallet_batch(
            db,
            offset=offset,
            limit=int(batch_size),
        )
        if not ids:
            break

        batches += 1
        before_map: dict[int, bool | None] = {}
        for tg_id in ids:
            before_map[tg_id] = await _read_users_is_vip(db, tg_id)

        await NftCheckService.sync_users_is_vip(
            db,
            ids,
            force_refresh=force_refresh,
        )

        for tg_id in ids:
            after = await _read_users_is_vip(db, tg_id)
            before = before_map.get(tg_id)
            if before is None or after is None:
                continue
            if before != after:
                changed_total += 1

        total += len(ids)
        await db.commit()
        offset += len(ids)

    return {
        "total": total,
        "changed": changed_total,
        "batches": batches,
    }


async def vip_health_snapshot(db: AsyncSession) -> dict[str, Any]:
    """Health-снимок: сколько с кошельком и сколько VIP."""
    all_sql = text("""
        SELECT COUNT(*)
        FROM efhc_core.users
        WHERE ton_wallet IS NOT NULL
          AND LENGTH(TRIM(ton_wallet)) > 0
        """
    )
    vip_sql = text("""
        SELECT COUNT(*) 
        FROM efhc_core.users
        WHERE is_vip = TRUE
        """
    )
    row_all: Result = await db.execute(all_sql)
    row_vip: Result = await db.execute(vip_sql)
    total_with_wallet = int(row_all.scalar() or 0)
    total_vip = int(row_vip.scalar() or 0) 
    return {
        "with_wallet": total_with_wallet,
        "vip": total_vip,
        "collection": TON_NFT_COLLECTION or "",
    }


async def run_daily_vip_check() -> dict[str, Any]:
    """Обёртка для планировщика: своя сессия и check_all_users_once."""
    session_factory = get_session_factory()
    async with session_factory() as db:
        stats = await check_all_users_once(
            db,
            batch_size=VIP_CHECK_BATCH_SIZE,
            force_refresh=False,
        )
        await db.commit()
        logger.info("VIP daily check finished: %s", stats)
        return stats


__all__ = [
    "NftAsset",
    "NftCheckResult",
    "NftCheckError",
    "NftCheckService",
    "check_user_vip_once",
    "check_users_subset",
    "check_all_users_once",
    "vip_health_snapshot",
    "run_daily_vip_check",
]