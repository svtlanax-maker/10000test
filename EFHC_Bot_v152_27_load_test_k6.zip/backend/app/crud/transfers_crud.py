# backend/app/crud/transfers_crud.py
# ======================================================================
# Назначение кода:
# Доменные выборки переводов/операций.
# В каноне EFHC нет P2P, есть логи «банк ↔ пользователь».
# Этот модуль — тонкий слой чтения журнала efhc_transfers_log.
# ======================================================================

from __future__ import annotations

from app.models.transactions_models import EfhcTransferLog
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession


async def list_user_ledger(
    db: AsyncSession,
    *,
    tg_id: int,
    limit: int = 200,
) -> list[EfhcTransferLog]:
    """Список записей журнала переводов по tg_id (desc)."""

    stmt = (
        select(EfhcTransferLog)
        .where(EfhcTransferLog.tg_id == int(tg_id))
        .order_by(EfhcTransferLog.id.desc())
        .limit(int(limit))
    )
    res = await db.execute(stmt)
    return list(res.scalars().all())
