# backend/app/routes/lotteries_routes.py
# ======================================================================
# Публичные ручки lotteries: витрина, статус, мои билеты, покупка.
#
# Канон:
# • TG-ID only (никакого public tg_id).
# • Курсоры: encode_cursor/decode_cursor возвращают dict.
# • Денежные POST: MUST Idempotency-Key.
# ======================================================================

from __future__ import annotations

from typing import Any

from app.core.logging_core import get_logger
from app.deps import (
    decode_cursor,
    encode_cursor,
    etag,
    get_current_tg_id,
    get_db,
    require_idempotency_key,
    require_wallet_connected,
)
from app.schemas.lotteries_schemas import (
    BuyTicketsIn,
    BuyTicketsOut,
    LatestWinnersOut,
    LotteriestatusOut,
    PaginatedLotteriesHistoryOut,
    PaginatedLotteriesOut,
    PaginatedTicketsOut,
)
from app.services.lotteries_service import (
    svc_buy_tickets,
    svc_get_latest_winners,
    svc_get_lotteries_status,
    svc_list_active_lotteries,
    svc_list_lotteries_history,
    svc_list_user_tickets,
)
from fastapi import (
    APIRouter,
    Depends,
    HTTPException,
    Query,
    Request,
    Response,
    status,
)
from sqlalchemy.ext.asyncio import AsyncSession

logger = get_logger(__name__)
router = APIRouter(prefix="/api", tags=["lotteries"])



async def _wallet_gate_lotteries(
    request: Request,
    db: AsyncSession = Depends(get_db),
    current_tg_id: int = Depends(get_current_tg_id),
) -> None:
    await require_wallet_connected(
        request=request,
        db=db,
        current_tg_id=int(current_tg_id),
        feature="lotteries",
    )
    return None



@router.get("/lotteries", response_model=PaginatedLotteriesOut)
async def list_active_lotteries(
    response: Response,
    limit: int = Query(20, ge=1, le=100),
    cursor: str | None = Query(
        None,
        description="Cursor (base64url(json dict))",
    ),
    db: AsyncSession = Depends(get_db),
) -> PaginatedLotteriesOut:
    after: dict[str, Any] | None = None
    if cursor:
        try:
            after = decode_cursor(cursor)
        except ValueError as err:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Некорректный cursor",
            ) from err

    items, next_after = await svc_list_active_lotteries(
        db,
        limit=int(limit),
        cursor=after,
    )
    body = PaginatedLotteriesOut(
        items=items,
        next_cursor=(encode_cursor(next_after) if next_after else None),
    )

    try:
        response.headers["ETag"] = etag(body.model_dump())
    except Exception:
        logger.warning(
            "ETag compute failed for /lotteries",
            exc_info=True,
        )

    return body


@router.get(
    "/lotteries/history",
    response_model=PaginatedLotteriesHistoryOut,
)
async def list_lotteries_history(
    response: Response,
    limit: int = Query(20, ge=1, le=100),
    cursor: str | None = Query(
        None,
        description="Cursor (base64url(json dict))",
    ),
    db: AsyncSession = Depends(get_db),
) -> PaginatedLotteriesHistoryOut:
    """История завершённых lotteries с результатами."""
    after: dict[str, Any] | None = None
    if cursor:
        try:
            after = decode_cursor(cursor)
        except ValueError as err:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Некорректный cursor",
            ) from err

    items, next_after = await svc_list_lotteries_history(
        db,
        limit=int(limit),
        cursor=after,
    )
    body = PaginatedLotteriesHistoryOut(
        items=items,
        next_cursor=(encode_cursor(next_after) if next_after else None),
    )

    try:
        response.headers["ETag"] = etag(body.model_dump())
    except Exception:
        logger.warning(
            "ETag compute failed for /lotteries/history",
            exc_info=True,
        )

    return body


@router.get(
    "/lotteries/winners/latest",
    response_model=LatestWinnersOut,
)
async def get_latest_winners(
    response: Response,
    db: AsyncSession = Depends(get_db),
) -> LatestWinnersOut:
    data = await svc_get_latest_winners(db)
    body = LatestWinnersOut(
        efhc=(data.get("EFHC") if data else None),
        vip=(data.get("NFT") if data else None),
    )
    try:
        response.headers["ETag"] = etag(body.model_dump())
    except Exception:
        logger.warning(
            "ETag compute failed for /lotteries/winners/latest",
            exc_info=True,
        )
    return body

@router.get(
    "/lotteries/{lotteries_id}",
    response_model=LotteriestatusOut,
)
async def get_lotteries_status(
    response: Response,
    lotteries_id: int,
    db: AsyncSession = Depends(get_db),
) -> LotteriestatusOut:
    st = await svc_get_lotteries_status(db, int(lotteries_id))
    if not st:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Lotteries not found",
        )

    body = LotteriestatusOut(**st)
    try:
        response.headers["ETag"] = etag(body.model_dump())
    except Exception:
        logger.warning(
            "ETag compute failed for /lotteries/{lotteries_id}",
            exc_info=True,
        )

    return body


@router.get(
    "/lotteries/{lotteries_id}/my-tickets",
    response_model=PaginatedTicketsOut,
)
async def list_my_tickets(
    response: Response,
    lotteries_id: int,
    limit: int = Query(50, ge=1, le=200),
    cursor: str | None = Query(
        None,
        description="Cursor (base64url(json dict))",
    ),
    tg_id: int = Depends(get_current_tg_id),
    db: AsyncSession = Depends(get_db),
) -> PaginatedTicketsOut:
    after: dict[str, Any] | None = None
    if cursor:
        try:
            after = decode_cursor(cursor)
        except ValueError as err:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Некорректный cursor",
            ) from err

    tickets, next_after = await svc_list_user_tickets(
        db,
        lotteries_id=int(lotteries_id),
        tg_id=int(tg_id),
        limit=int(limit),
        cursor=after,
    )

    body = PaginatedTicketsOut(
        items=tickets,
        next_cursor=(encode_cursor(next_after) if next_after else None),
    )
    try:
        response.headers["ETag"] = etag(body.model_dump())
    except Exception:
        logger.warning(
            (
                "ETag compute failed for "
                "/lotteries/{lotteries_id}/my-tickets"
            ),
            exc_info=True,
        )

    return body


@router.post(
    "/lotteries/{lotteries_id}/buy",
    response_model=BuyTicketsOut,
)
async def buy_tickets(
    request: Request,
    response: Response,
    lotteries_id: int,
    body: BuyTicketsIn,
    tg_id: int = Depends(get_current_tg_id),
    db: AsyncSession = Depends(get_db),
    _wallet=Depends(_wallet_gate_lotteries),
    idk: str = Depends(require_idempotency_key),
) -> BuyTicketsOut:
    try:
        res = await svc_buy_tickets(
            db,
            lotteries_id=int(lotteries_id),
            tg_id=int(tg_id),
            qty=int(body.qty),
            idempotency_key=str(idk),
            wallet_address=(
                str(body.wallet_address).strip()
                if body.wallet_address
                else None
            ),
        )
    except HTTPException:
        raise
    except Exception as e:
        logger.exception("buy_tickets failed: %s", e)
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Временная ошибка покупки",
        ) from e

    out = BuyTicketsOut(**res)
    try:
        response.headers["ETag"] = etag(out.model_dump())
    except Exception:
        logger.warning(
            "ETag compute failed for /lotteries/{lotteries_id}/buy",
            exc_info=True,
        )

    return out