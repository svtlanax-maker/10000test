# backend/app/routes/wallets_routes.py

from __future__ import annotations

from app.deps import (
    get_current_tg_id,
    get_db,
    require_idempotency_key_header_only,
)
from app.services import wallets_service
from fastapi import APIRouter, Depends, HTTPException, Request, status
from pydantic import BaseModel, Field
from sqlalchemy.ext.asyncio import AsyncSession

router = APIRouter(prefix="/wallets", tags=["wallets"])


class WalletConnectIn(BaseModel):
    address: str = Field(..., min_length=1, max_length=256)
    wallet_app: str | None = Field(default=None, max_length=32)


class WalletConnectOut(BaseModel):
    wallet_id: int
    wallet_address: str
    is_connected: bool


class WalletItem(BaseModel):
    id: int
    wallet_address: str
    wallet_app: str | None
    is_primary: bool
    is_active: bool
    created_at: str


class WalletMeOut(BaseModel):
    is_connected: bool
    wallets: list[WalletItem]


@router.get(
    "/me",
    response_model=WalletMeOut,
    summary="Список привязанных кошельков пользователя",
)
async def wallets_me(
    request: Request,
    db: AsyncSession = Depends(get_db),
    current_tg_id: int = Depends(get_current_tg_id),
) -> WalletMeOut:
    tg_id = int(current_tg_id)
    items = await wallets_service.list_wallets(db, tg_id=tg_id)
    wallets = [WalletItem(**w.__dict__) for w in items]
    return WalletMeOut(
        is_connected=any(w.is_active for w in wallets),
        wallets=wallets,
    )


@router.post(
    "/connect",
    response_model=WalletConnectOut,
    summary="Привязать TON-кошелёк к tg_id (TonConnect)",
)
async def connect_wallet(
    request: Request,
    payload: WalletConnectIn,
    db: AsyncSession = Depends(get_db),
    current_tg_id: int = Depends(get_current_tg_id),
    _idk: str = Depends(require_idempotency_key_header_only),
) -> WalletConnectOut:
    tg_id = int(current_tg_id)

    try:
        res = await wallets_service.connect_wallet(
            db,
            tg_id=tg_id,
            address=payload.address,
            wallet_app=payload.wallet_app,
            idempotency_key=_idk,
        )
        return WalletConnectOut(**res)
    except wallets_service.InvalidWalletAddress as err:
        raise HTTPException(
            status_code=400,
            detail={"code": "INVALID_WALLET_ADDRESS"},
        ) from err
    except wallets_service.WalletConflict as err:
        raise HTTPException(
            status_code=409,
            detail={"code": "WALLET_CONFLICT"},
        ) from err


@router.post(
    "/{wallet_id}/make-primary",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Сделать кошелёк primary",
)
async def make_primary(
    request: Request,
    wallet_id: int,
    db: AsyncSession = Depends(get_db),
    current_tg_id: int = Depends(get_current_tg_id),
) -> None:
    tg_id = int(current_tg_id)
    await wallets_service.make_primary(
        db,
        tg_id=tg_id,
        wallet_id=wallet_id,
    )


@router.delete(
    "/{wallet_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Деактивировать привязку кошелька",
)
async def delete_wallet(
    request: Request,
    wallet_id: int,
    db: AsyncSession = Depends(get_db),
    current_tg_id: int = Depends(get_current_tg_id),
) -> None:
    tg_id = int(current_tg_id)
    await wallets_service.deactivate_wallet(
        db,
        tg_id=tg_id,
        wallet_id=wallet_id,
    )
