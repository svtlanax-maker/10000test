# backend/app/scheduler/jobs/job_healthcheck_ping.py
# ======================================================================
# Bridge-job: вызывает run_once() из scheduler.healthcheck_ping.
# ======================================================================

from __future__ import annotations

