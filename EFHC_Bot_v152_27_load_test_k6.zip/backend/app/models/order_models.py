# backend/app/models/order_models.py
# ======================================================================
# Назначение:
# Исторический модуль для обратной совместимости импортов.
#
# В проекте таблица `shop_orders` должна иметь ЕДИНСТВЕННОЕ ORM-
# определение.
# Каноничный источник истины: backend/app/models/shop_models.py
# (ShopOrder).
#
# Этот файл НЕ объявляет ORM-таблицу, а только ре-экспортирует
# каноничный класс.

from __future__ import annotations

from ..models.shop_models import ShopOrder  # noqa: F401

__all__ = ["ShopOrder"]
