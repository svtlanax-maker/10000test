# backend/app/bot/handlers/admin/admin_shop_handlers.py
# ======================================================================
# Назначение кода:
# Админ-команда admin_shop: безопасная точка входа в админ-операции
# через WebApp.
# Канон: админ-логика и деньги выполняются ТОЛЬКО через backend API и
# services слой.
# ======================================================================
from __future__ import annotations

from aiogram import Router
from aiogram.filters import Command
from aiogram.types import Message
from app.bot.keyboards import kb_main_menu
from app.core.config_core import get_settings

router = Router()
settings = get_settings()


def _is_admin(tg_id: int) -> bool:
    """Проверка права админа по tg_id."""
    return int(tg_id) == int(getattr(settings, "ADMIN_TG_ID", 0))


@router.message(Command("admin_shop"))
async def handler(message: Message) -> None:
    """Показывает точку входа в Admin → Shop (WebApp)."""
    if not message.from_user:
        return
    if not _is_admin(message.from_user.id):
        await message.answer("⛔ Нет доступа.")
        return

    await message.answer(
        "🛒 Управление Shop доступно в WebApp → Admin → Shop.",
        reply_markup=kb_main_menu(),
    )
