# backend/app/bot/handlers/admin/admin_withdrawals_handlers.py
# ----------------------------------------------------------------------
# Назначение кода:
# /admin_withdrawals — вход в раздел Admin → Withdrawals в WebApp.
# ----------------------------------------------------------------------

from __future__ import annotations

from aiogram import Router
from aiogram.filters import Command
from aiogram.types import Message
from app.bot.keyboards import kb_main_menu
from app.core.config_core import get_settings

router = Router()
settings = get_settings()


def _is_admin(tg_id: int) -> bool:
    """Проверяет tg_id на совпадение с admin tg_id из настроек."""
    admin_tg_id = int(getattr(settings, "ADMIN_TG_ID", 0))
    return int(tg_id) == admin_tg_id


@router.message(Command("admin_withdrawals"))
async def handler(message: Message) -> None:
    """Команда /admin_withdrawals — отдаёт навигацию к WebApp."""
    if not message.from_user:
        return

    if not _is_admin(message.from_user.id):
        await message.answer("⛔ Нет доступа.")
        return

    await message.answer(
        "💸 Обработка выводов доступна в WebApp → Admin → Withdrawals.",
        reply_markup=kb_main_menu(),
    )
