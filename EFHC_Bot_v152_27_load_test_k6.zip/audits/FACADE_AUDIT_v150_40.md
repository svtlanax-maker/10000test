# EFHC Facade Audit v150_40

Цель: внедрить фасады для коротких импортов без агрегации в __init__.py.

## Найдено

1) backend/app/services/__init__.py — безопасный (без агрегации).
2) backend/app/schemas/__init__.py — безопасный (без агрегации).
3) В коде встречаются импорты вида:
   - from app.services import <module>
   - from app.schemas import <name>
   Это допустимо при безопасных __init__.py, но не даёт преимущества.

## Сделано

1) Добавлен services facade:
   backend/app/services/facade.py

2) Добавлен schemas facade:
   backend/app/schemas/facade.py

3) Обновлён канон (docs/EFHC_CANON.md):
   - запрет агрегации в __init__.py
   - разрешение facade.py без побочных эффектов

## Рекомендация

Использовать фасады в новых модулях для коротких импортов:
- from app.services.facade import ...
- from app.schemas.facade import ...

Не расширять фасады бесконтрольно: держать список экспортов малым.
