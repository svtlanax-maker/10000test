# Alias sanitation report v150_24

- Replacements:
  - ADMIN_BANK_TG_ID → BANK_EFHC: 18
  - direction IN/OUT → credit/debit (admin users adjust): 4

- Files touched (code/tests):
  - backend/app/core/__init__.py
  - backend/app/core/config_core.py
  - backend/app/core/security_core.py
  - backend/app/deps.py
  - backend/app/scheduler/bankstate_recalc.py
  - backend/app/services/admin/admin_users_service.py
  - backend/app/services/transactions_service.py
  - tests/architecture/test_forbidden_identifiers_repo.py
  - tests/conftest.py
  - tests/test_concurrency_exchange_withdraw.py
