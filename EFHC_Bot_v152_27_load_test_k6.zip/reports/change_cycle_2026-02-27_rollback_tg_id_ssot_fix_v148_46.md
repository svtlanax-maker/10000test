# v148_46 — SSOT tg_id unification + FK fixes

Дата: 2026-02-27 (Europe/Uzhgorod)

## Причина
По предоставленному аудиту выявлено расхождение семантики `tg_id`:
часть кода трактовала `tg_id` как Telegram user.id, а часть — как
внутренний PK `users.id`. Также модели/миграция использовали FK
`tg_id -> users.id`, что противоречит канону SSOT.

## Что сделано
- backend/app/crud/user_crud.py: все фильтры `User.id == int(tg_id)`
  заменены на `User.tg_id == int(tg_id)`.
- backend/app/services/exchange_service.py: запросы к `{SCHEMA}.users`
  переведены с `WHERE id = :id` на `WHERE tg_id = :tg_id`.
- backend/app/models/withdraw_models.py и achievements_models.py:
  FK переведены на `users.tg_id`.
- backend/migrations/versions/0001_init.py:
  - withdraw_requests.tg_id FK -> efhc_core.users.tg_id
  - добавлена таблица achievements (schema efhc_core)
  - op.create_foreign_key дополнен source_schema/referent_schema="efhc_core"
- backend/app/models/user_models.py: удалён дубликат `class User(Base):`.
- frontend/src/pages/admin/users.tsx: убран `Number(...)` для балансов,
  сумма считается через `sumScaledDown(..., 8)`.

## Проверка
- python -m compileall backend -q
- python -m compileall tests -q
(полный pytest подтверждается CI)

