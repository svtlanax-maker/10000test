# Change Cycle — 2026-02-28 05:00 UTC — v149_17

## Summary
Добавлены 2 новых SSOT-аудита в docs/audits/ (JSON-навигация, README,
линтеры проходят). Аудиты привязаны к первичным PDF-источникам в
docs/audits/_raw/ и имеют Evidence Index.

## Added Audits
- AUD-2026-02-28-ROUTES-INVENTORY-003
  - File: docs/audits/2026-02-28_routes-inventory_v149_17__route_table_map.md
  - Source: docs/audits/_raw/AUD-2026-02-28-ROUTES-INVENTORY-003.pdf
- AUD-2026-02-28-DB-INVENTORY-005
  - File: docs/audits/2026-02-28_db-inventory_v149_17__duplicates_passport.md
  - Source: docs/audits/_raw/AUD-2026-02-28-DB-INVENTORY-005.pdf

## Files Changed
- docs/audits/audits_index.json
- docs/audits/README.md (generated)
- docs/audits/audits.schema.json (unchanged)
- ops/audits_index_lint.py (unchanged)
- ops/audits_md_lint.py (unchanged)
- ops/audits_readme_generate.py (unchanged)

## Verification
- python ops/audits_index_lint.py  (PASS)
- python ops/audits_md_lint.py     (PASS)
- python ops/audits_readme_generate.py --check (PASS)

