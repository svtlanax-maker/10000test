# Change cycle v148_45 — pytest-asyncio strict: async fixtures

Дата/время: 2026-02-27 18:05 UTC (логический штамп цикла)

## Симптом (CI)
- pytest падал на setup concurrency тестов с предупреждением/ошибкой:
  PytestRemovedIn9Warning: requested an async fixture 'async_engine' ...
- Далее цепочкой ломались setup/runner фикстуры.

## Root cause
Async fixtures были объявлены через `@pytest.fixture`, но в режиме
`pytest-asyncio` STRICT корректный путь — использовать
`@pytest_asyncio.fixture` для async fixtures.

Также `_ensure_schema()` собирал SQL неверно (передавал несколько
аргументов в `sqlalchemy.text()`), что потенциально ломало создание схем.

## Fix
- `tests/conftest.py`:
  - импорт `pytest_asyncio`
  - async fixtures переведены на `@pytest_asyncio.fixture`
    (`async_engine`, `schemas_ready`, `db_migrated`, `db_clean`,
    `db_session`)
  - `_ensure_schema()` переписан на корректный SQL-строковый stmt

## Verification
- python -m compileall tests -q (ожидаемо PASS)
- CI: pytest-asyncio STRICT должен корректно обработать async fixtures
