# Change report v148_41 — fix 0001 tables + remove stray artifacts

Дата/время (Europe/Uzhgorod): 2026-02-27 23:55

## Причина (по CI logs_58820276444.zip)
- pytest падал из-за отсутствующих таблиц после `alembic upgrade head`:
  - `efhc_core.withdraw_requests` отсутствовала
  - `efhc_admin.efhc_sale_packages` отсутствовала
- В проекте были мусорные артефакты `orders_service.py.new*`, которые не должны
  присутствовать в репозитории.

## Что сделано

### 1) Миграции: 0001_init.py (канон: все таблицы в 0001)
Файл: `backend/migrations/versions/0001_init.py`

- Добавлена таблица `efhc_core.withdraw_requests` (каноничная заявка на вывод),
  включая UNIQUE по `idempotency_key` и индексы по `tg_id`/`status`.
- Для всех таблиц в 0001 явным образом задан `schema=...`:
  - core-таблицы: `schema="efhc_core"`
  - admin-таблицы: `schema="efhc_admin"`
  Это устраняет зависимость от search_path/env и гарантирует, что таблицы
  создаются в ожидаемых схемах.

### 2) Удаление артефактов
Удалены файлы (мусор/черновики):
- `backend/app/services/orders_service.py.new`
- `backend/app/services/orders_service.py.new2`

Файл `backend/orders_service.py` отсутствовал и не требовал удаления.

## Проверки
- `python -m compileall backend -q` (локально) — OK

## Примечание (SSOT)
Требование: таблицы/схемы должны быть созданные в `0001`.
Дальнейшие изменения схемы — только через расширение 0001 (без добавления новых
ревизий), пока это правило активно.
