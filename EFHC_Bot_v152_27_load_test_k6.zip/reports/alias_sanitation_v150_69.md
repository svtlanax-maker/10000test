# Alias sanitation report v150_69

Цель: устранить остатки backend.app.* и
проверить отсутствие tg_id-алиасов.

## Итог по скоупу backend/frontend
- backend: backend.app.* = 0, tg-aliases = 0
- frontend: backend.app.* = 0, tg-aliases = 0

## CI
- Добавлен шаг flake8 (critical) в ci.yml.
- Используется конфиг .flake8 (select=E9,F7,F82).
