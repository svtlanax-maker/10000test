# ops/ci_verify_db_objects.py
# =====================================================================
# EFHC Bot — CI sanity: объекты БД после alembic upgrade head.
#
# Проверяем:
# 1) существуют схемы efhc_core и efhc_admin
# 2) существуют ВСЕ таблицы из docs/ssot_pack/SSOT_TABLES_ORM.csv
#
# Важно:
# - это Postgres-only.
# - вход: PSYCOPG_URL или DATABASE_URL.
# =====================================================================

from __future__ import annotations

import csv
import os
import sys
from pathlib import Path

import psycopg

ROOT = Path(__file__).resolve().parents[1]
SSOT_TABLES = ROOT / "docs" / "ssot_pack" / "SSOT_TABLES_ORM.csv"

CANON_SCHEMAS = ["efhc_core", "efhc_admin"]


def _fq(schema: str, table: str) -> str:
    return f"{schema}.{table}"


def _read_required_pairs() -> list[tuple[str, str]]:
    if not SSOT_TABLES.exists():
        raise RuntimeError("SSOT_TABLES_ORM.csv missing")

    out: set[tuple[str, str]] = set()
    with SSOT_TABLES.open("r", encoding="utf-8") as f:
        r = csv.DictReader(f)
        for row in r:
            schema = (row.get("schema") or "").strip()
            table = (row.get("table") or "").strip()
            if not schema or not table:
                continue
            out.add((schema, table))

    return sorted(out, key=lambda x: (x[0], x[1]))


def _find_table_locations(cur: psycopg.Cursor, table: str) -> list[str]:
    cur.execute(
        "\n".join(
            [
                "SELECT n.nspname",
                "FROM pg_class c",
                "JOIN pg_namespace n ON n.oid = c.relnamespace",
                "WHERE c.relkind = 'r' AND c.relname = %s",
                "ORDER BY n.nspname",
            ]
        ),
        (table,),
    )
    return [r[0] for r in cur.fetchall()]


def main() -> int:
    url = os.getenv("PSYCOPG_URL") or os.getenv("DATABASE_URL")
    if not url:
        print(
            "ERROR: PSYCOPG_URL or DATABASE_URL is required",
            file=sys.stderr,
        )
        return 2

    required_pairs = _read_required_pairs()

    missing: list[str] = []
    hints: list[str] = []

    with psycopg.connect(url) as conn, conn.cursor() as cur:
        # Диагностика: в какой БД и с каким search_path проверяем.
        try:
            cur.execute("SELECT current_database()")
            db = cur.fetchone()[0]
            cur.execute("SELECT current_schema()")
            cs = cur.fetchone()[0]
            cur.execute("SHOW search_path")
            sp = cur.fetchone()[0]
            print(f"DB diag: db={db} schema={cs}")
            print(f"DB diag: search_path={sp}")
        except Exception:
            print("DB diag: unavailable")

        # 1) схемы
        for s in CANON_SCHEMAS:
            cur.execute(
                "SELECT 1 FROM pg_namespace WHERE nspname = %s",
                (s,),
            )
            if cur.fetchone() is None:
                missing.append(f"schema:{s}")

        # 2) таблицы
        for schema, table in required_pairs:
            fq = _fq(schema, table)
            cur.execute("SELECT to_regclass(%s)", (fq,))
            val = cur.fetchone()[0]
            if val is None:
                missing.append(fq)
                cur.execute(
                    "SELECT to_regclass(%s)",
                    (f"public.{table}",),
                )
                pub = cur.fetchone()[0]
                if pub is not None:
                    hints.append(
                        "HINT: "
                        f"{fq} missing; exists as public.{table}"
                    )
                loc = _find_table_locations(cur, table)
                if loc:
                    msg = (
                        f"HINT: {fq} missing; '{table}' exists in "
                        f"schemas: {', '.join(loc)}"
                    )
                    hints.append(msg)

    if missing:
        print(
            "ERROR: required DB objects missing after alembic:",
            file=sys.stderr,
        )
        for t in missing:
            print(f" - {t}", file=sys.stderr)
        if hints:
            print("---- diagnostics ----", file=sys.stderr)
            for h in hints:
                print(h, file=sys.stderr)
        return 2

    print(
        "OK: all required DB objects exist "
        f"({len(required_pairs)} tables / "
        f"{len(CANON_SCHEMAS)} schemas)."
    )
    print("Schemas: " + ", ".join(CANON_SCHEMAS))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
