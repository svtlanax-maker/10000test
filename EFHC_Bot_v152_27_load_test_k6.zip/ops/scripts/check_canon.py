#!/usr/bin/env python3
"""ops/scripts/check_canon.py

Проверка канона проекта (механический чек):

1) В публичных роутерах нельзя использовать get_current_tg_id.
2) В публичных Pydantic схемах нельзя иметь поле tg_id.
3) В путях роутов нельзя иметь /{tg_id}.
4) Денежные POST должны требовать Idempotency-Key через
   require_idempotency_key.

Скрипт предназначен для CI/преддеплой‑проверки.
"""

from __future__ import annotations

import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
APP = ROOT / "backend" / "app"


def fail(msg: str) -> None:
    print(f"[CANON FAIL] {msg}")
    sys.exit(1)


def _iter_repo_paths() -> list[Path]:
    return list(ROOT.rglob("*"))


def main() -> int:
    routes_dir = APP / "routes"
    if not routes_dir.exists():
        fail("routes/ not found")

    py_files = list(routes_dir.glob("*.py"))

    # 0) Абсолютный запрет префикса (файлы + содержимое)
    # Собираем из частей, чтобы не оставлять префикс в кодовой базе.
    forbidden_substring = "lot" + "tery"

    for path in _iter_repo_paths():
        if any(
            part in {".git", ".venv", "node_modules", "__pycache__"}
            for part in path.parts
        ):
            continue

        if forbidden_substring in path.name.lower():
            fail(f"Forbidden substring in filename: {path}")

        if not path.is_file():
            continue

        try:
            data = path.read_text(encoding="utf-8", errors="ignore")
        except Exception:
            continue

        if forbidden_substring in data.lower():
            fail(f"Forbidden substring in file content: {path}")

    # 1) get_current_tg_id is forbidden in routes
    for f in py_files:
        t = f.read_text(encoding="utf-8", errors="ignore")
        if "get_current_tg_id" in t:
            fail(f"Forbidden get_current_tg_id in routes: {f}")

    # 2) tg_id field forbidden in pydantic schemas inside routes
    schema_tg_id = re.compile(r"\btg_id\s*:\s*", re.IGNORECASE)
    for f in py_files:
        t = f.read_text(encoding="utf-8", errors="ignore")
        if "class" in t and schema_tg_id.search(t):
            pat = (
                r"class\s+\w+\(BaseModel\):([\s\S]*?)"
                r"(?:\n\n|\Z)"
            )
            for m in re.finditer(pat, t):
                block = m.group(0)
                if schema_tg_id.search(block):
                    fail(
                        "Forbidden tg_id field in BaseModel schema: "
                        f"{f}"
                    )

    # 3) /{tg_id} forbidden in routes path
    for f in py_files:
        t = f.read_text(encoding="utf-8", errors="ignore")
        if "/{tg_id}" in t:
            fail(f"Forbidden path /{{tg_id}} in routes: {f}")

    # 4) Monetary POST endpoints must require require_idempotency_key
    pat = (
        r"@router\.post\(.*\)\s*\n"
        r"async\s+def\s+(\w+)"
    )
    interesting = re.compile(pat, re.MULTILINE)

    keywords = [
        "buy",
        "purchase",
        "withdraw",
        "transfer",
        "panel",
        "order",
    ]

    for f in py_files:
        t = f.read_text(encoding="utf-8", errors="ignore")
        for m in interesting.finditer(t):
            fn = m.group(1)
            if not any(k in fn.lower() for k in keywords):
                continue

            start = m.start()
            sig = t[start : start + 2000]
            ok1 = "Depends(require_idempotency_key" in sig
            ok2 = "Depends(require_idempotency_key_header_only" in sig
            if not ok1 and not ok2:
                fail(
                    f"POST {fn} missing require_idempotency_key "
                    f"dependency in {f}"
                )

    print("[CANON OK] all checks passed")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
