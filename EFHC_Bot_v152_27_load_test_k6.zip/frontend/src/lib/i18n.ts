export type Lang =
  | "ru"
  | "en"
  | "ua"
  | "de"
  | "fr"
  | "es"
  | "it"
  | "tr"
  | "pl"
  | "da"
  | "hi"
  | "id"
  | "sw";

// Order is UX-only (language selector). Default language is still RU.
// Per product requirement: the selector starts with EN.
export const SUPPORTED_LANGS: Lang[] = [
  "en",
  "ru",
  "ua",
  "de",
  "fr",
  "es",
  "it",
  "tr",
  "pl",
  "da",
  "hi",
  "id",
  "sw",
];

export function normalizeLang(input?: string | null): Lang {
  const lc = (input || "").toLowerCase();
  if (lc.startsWith("uk")) return "ua";
  if (lc.startsWith("ru")) return "ru";
  if (lc.startsWith("en")) return "en";
  if (lc.startsWith("de")) return "de";
  if (lc.startsWith("fr")) return "fr";
  if (lc.startsWith("es")) return "es";
  if (lc.startsWith("it")) return "it";
  if (lc.startsWith("tr")) return "tr";
  if (lc.startsWith("pl")) return "pl";
  if (lc.startsWith("da")) return "da";
  if (lc.startsWith("hi")) return "hi";
  if (lc.startsWith("id")) return "id";
  if (lc.startsWith("sw")) return "sw";
  return "ru";
}

export type Dict = Record<string, string>;

export async function loadDict(lang: Lang): Promise<Dict> {
  const res = await fetch(`/locale/${lang}.json`, {
    cache: "no-store",
  });
  if (!res.ok) throw new Error(`Failed to load locale ${lang}`);
  return (await res.json()) as Dict;
}


export function tFromDicts(k: string, dict: Dict, ru: Dict): string {
  return dict[k] || ru[k] || k;
}
