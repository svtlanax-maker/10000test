import type { Lang } from "./i18n";

export type UserSettings = {
  lang: Lang; // descriptions language

  // Theme handling (Telegram-only): auto uses Telegram colorScheme,
  // otherwise forces the UI.
  theme_mode: "auto" | "dark" | "light";
  // Avatar handling
  avatar_source: "telegram" | "custom";
  // user-chosen override; default comes from Telegram
  avatar_url?: string | null;

  // Sound & haptics
  sfx_enabled: boolean;
  sfx_volume: number; // 0..1
  sfx_pack: "default";
  haptics_enabled: boolean;

  // Display & privacy
  reduce_motion: boolean;
  hide_balances: boolean;
  show_decimal_detail: boolean;

  // Confirmations
  confirm_actions: boolean;
  confirm_purchase: boolean;
  confirm_withdraw: boolean;
  confirm_convert: boolean;
  confirm_watch_ad: boolean;

  // In-app notifications
  toasts_enabled: boolean;
  important_alerts_only: boolean;
};

const KEY = "EFHC_USER_SETTINGS_V2";

export const DEFAULT_SETTINGS: UserSettings = {
  lang: "en",
  theme_mode: "auto",
  avatar_source: "telegram",
  avatar_url: null,
  sfx_enabled: true,
  sfx_volume: 0.6,
  sfx_pack: "default",
  haptics_enabled: true,
  reduce_motion: false,
  hide_balances: false,
  show_decimal_detail: false,
  confirm_actions: true,
  confirm_purchase: true,
  confirm_withdraw: true,
  confirm_convert: true,
  confirm_watch_ad: true,
  toasts_enabled: true,
  important_alerts_only: false,
};

export function resetSettings(): UserSettings {
  return { ...DEFAULT_SETTINGS };
}

export function loadSettings(): UserSettings {
  if (typeof window === "undefined") return DEFAULT_SETTINGS;
  try {
    const raw = window.localStorage.getItem(KEY);
    if (!raw) return DEFAULT_SETTINGS;
    const parsed = JSON.parse(raw);
    return { ...DEFAULT_SETTINGS, ...(parsed || {}) } as UserSettings;
  } catch {
    return DEFAULT_SETTINGS;
  }
}

export function saveSettings(s: UserSettings): void {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(KEY, JSON.stringify(s));
  } catch {
    // ignore
  }
}
