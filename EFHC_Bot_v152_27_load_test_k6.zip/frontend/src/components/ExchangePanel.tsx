import React, { useMemo, useState } from "react";
import { Card } from "./ui/Card";
import { Button } from "./ui/Button";
import {
  format8,
  fromScaledBigint,
  toScaledBigintDown,
} from "../lib/format";

type Props = {
  maxKwh: string;
  onExchange: (amountKwh: string) => Promise<void>;
};

export function ExchangePanel(props: Props) {
  const maxScaled = useMemo(() => {
    return toScaledBigintDown(props.maxKwh || "0", 8);
  }, [props.maxKwh]);
  const [amount, setAmount] = useState("0.00000000");

  function setPct(pct: number) {
    const p = BigInt(Math.max(0, Math.min(100, pct)));
    const scaled = (maxScaled * p) / 100n;
    setAmount(fromScaledBigint(scaled, 8));
  }

  return (
    <Card title="Exchange">
      <div className="text-sm text-gray-600">kWh → EFHC (1:1)</div>
      <div className="text-xs text-gray-500 mt-1">
        Max: {fromScaledBigint(maxScaled, 8)}
      </div>

      <div className="grid grid-cols-3 gap-2 mt-2">
        <Button variant="secondary" onClick={() => setPct(25)}>
          25%
        </Button>
        <Button variant="secondary" onClick={() => setPct(50)}>
          50%
        </Button>
        <Button variant="secondary" onClick={() => setPct(100)}>
          100%
        </Button>
      </div>

      <input
        className="border rounded-xl px-3 py-2 w-full mt-2"
        value={amount}
        onChange={(e) => setAmount(e.target.value)}
        inputMode="decimal"
      />

      <Button className="mt-3 w-full"
        onClick={() => props.onExchange(amount)}
      >
        Exchange
      </Button>
    </Card>
  );
}
