import React from "react";
import { Card } from "./ui/Card";

export function RanksTable() {
  return (
    <Card title="Ranks">
      <div className="text-sm text-gray-600">TOP-100 + Я</div>
    </Card>
  );
}
