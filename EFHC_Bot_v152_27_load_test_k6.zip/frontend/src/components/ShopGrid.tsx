import React from "react";
import { Card } from "./ui/Card";

export function ShopGrid() {
  return (
    <Card title="Shop">
      <div className="text-sm text-gray-600">
        Подключение к backend будет сделано через /api/shop
      </div>
    </Card>
  );
}
