import { useCallback, useState } from "react";
import { apiRequest } from "../lib/api";

export function useCursorList<T>(path: string) {
  const [items, setItems] = useState<T[]>([]);
  const [cursor, setCursor] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [done, setDone] = useState(false);

  const reset = useCallback(() => {
    setItems([]);
    setCursor(null);
    setDone(false);
  }, []);

  const loadMore = useCallback(async () => {
    if (loading || done) return;
    setLoading(true);
    try {
      const q = cursor ? `?cursor=${encodeURIComponent(cursor)}` : "";
      const res = await apiRequest<{
        items: T[];
        next_cursor: string | null;
      }>(`${path}${q}`, "GET");
      setItems((prev) => [...prev, ...res.items]);
      setCursor(res.next_cursor);
      if (!res.next_cursor) setDone(true);
    } finally {
      setLoading(false);
    }
  }, [path, cursor, loading, done]);

  return { items, cursor, loading, done, loadMore, reset };
}
