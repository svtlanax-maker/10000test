import React, { useContext, useEffect, useMemo, useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { Card } from "../components/ui/Card";
import { Button } from "../components/ui/Button";
import { Badge } from "../components/ui/Badge";
import { Skeleton } from "../components/ui/Skeleton";
import { apiRequest } from "../lib/api";
import { newIdempotencyKey } from "../lib/idempotency";
import { useT } from "../hooks/useT";
import { useTD } from "../hooks/useTD";
import type { SyncSnapshot } from "../hooks/useSnapshot";
import { LayoutContext } from "../components/Layout";
import { EmptyState } from "../components/ui/EmptyState";
import { format8 } from "../lib/format";
import {
  hapticImpact,
  telegramMainButtonOnClick,
  telegramMainButtonSet,
} from "../lib/telegram";

type PanelItem = {
  id: number;
  public_id?: string | null;
  activated_at?: string | null;
  created_at?: string | null;
  expires_at?: string | null;
  archived_at?: string | null;
  base_gen_per_sec: string;
  generated_kwh: string;
  is_active: boolean;
};

function pad2(v: number): string {
  return v < 10 ? `0${v}` : String(v);
}

function formatUtcMinute(iso: string | null | undefined): string {
  if (!iso) return "—";
  const ms = Date.parse(iso);
  if (Number.isNaN(ms)) return "—";
  const d = new Date(ms);
  const dd = pad2(d.getUTCDate());
  const mm = pad2(d.getUTCMonth() + 1);
  const yy = String(d.getUTCFullYear());
  const hh = pad2(d.getUTCHours());
  const mi = pad2(d.getUTCMinutes());
  return `${dd}.${mm}.${yy} ${hh}:${mi} UTC`;
}

function formatRemaining(remainingSeconds: number | null): string {
  if (remainingSeconds === null) return "—";
  const s = Math.max(0, Math.floor(remainingSeconds));
  const days = Math.floor(s / 86_400);
  const hours = Math.floor((s % 86_400) / 3_600);
  const mins = Math.floor((s % 3_600) / 60);
  return `${days}д ${hours}ч ${mins}м`;
}

export default function PanelsPage(
  props: { tg_id: number | null; snap: SyncSnapshot | null },
) {
  const t = useT();
  const td = useTD();
  const tg_id = props.tg_id;
  const { confirm, toast, settings } = useContext(LayoutContext);
  const qc = useQueryClient();

  const [tab, setTab] = useState<"active" | "archive">("active");
  const [items, setItems] = useState<PanelItem[]>([]);
  const [cursor, setCursor] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [tick, setTick] = useState(0);

  const summary = props.snap?.panels;
  const profile = props.snap?.profile;
  const meta = props.snap?.meta;

  const activePanels = summary?.active_count ?? null;
  const genPerSecEffective = meta?.gen_per_sec_effective ?? null;

  // Optional display fields: show only if present in snapshot.
  const genPerSecBase = profile?.gen_per_sec_base ?? null;
  const genPerSecVip = profile?.gen_per_sec_vip ?? null;
  const isVip = Boolean(profile?.is_vip);

  // SSOT time anchor.
  // MUST: local device clock is not the source of truth.
  // server_now_iso is the anchor.
  // Local time is used only as a stopwatch.
  const serverNowIso = meta?.server_now_iso ?? null;
  const [anchorServerMs, setAnchorServerMs] =
    useState<number | null>(null);
  const [anchorClientMs, setAnchorClientMs] =
    useState<number | null>(null);

  useEffect(() => {
    if (!serverNowIso) {
      setAnchorServerMs(null);
      setAnchorClientMs(null);
      return;
    }
    const ms = Date.parse(serverNowIso);
    if (Number.isNaN(ms)) {
      setAnchorServerMs(null);
      setAnchorClientMs(null);
      return;
    }
    setAnchorServerMs(ms);
    setAnchorClientMs(Date.now());
  }, [serverNowIso]);

  useEffect(() => {
    const id = globalThis.setInterval(() => {
      setTick((v) => v + 1);
    }, 1_000);
    return () => globalThis.clearInterval(id);
  }, []);

  const nowUtcMs = useMemo(() => {
    if (anchorServerMs === null || anchorClientMs === null) return null;
    const delta = Date.now() - anchorClientMs;
    return anchorServerMs + delta;
  }, [anchorServerMs, anchorClientMs, tick]);

  const load = async (reset: boolean) => {
    if (!tg_id) return;
    if (loading) return;
    setLoading(true);
    setErr(null);
    try {
      const base = tab === "active" ?
        `/panels/${tg_id}/active`
        : `/panels/${tg_id}/archive`;
      const q = !reset && cursor ? `?
        cursor=${encodeURIComponent(cursor)}`
        : "";
      const res = await apiRequest<
        { items: PanelItem[]; next_cursor: string | null }
      >(base + q, "GET");
      setItems((prev) => (reset ? res.items : [...prev, ...res.items]));
      setCursor(res.next_cursor);
    } catch (e: any) {
      setErr(String(e?.message || e));
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    setItems([]);
    setCursor(null);
    load(true);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tab, tg_id]);

  const canLoadMore = Boolean(cursor);

  const buyPanel = async () => {
    if (!tg_id) return;
    // Canon: panel purchase is exactly 1 and only in Panels section.
    const ok = await confirm(
      "purchase",
      t("panels.buy_panel"),
      t("panels.subtitle_price_100"),
    );
    if (!ok) return;
    const idk = newIdempotencyKey();

    // Canon route: one buy endpoint, one panel per call.
    await apiRequest(`/panels/buy/${tg_id}`, "POST", {
      idempotencyKey: idk,
    });

    toast(t("panels.buy_ok"), "success");
    await qc.invalidateQueries({
      queryKey: ["syncSnapshot", tg_id],
    });

    // Snapshot refresh is global; keep this page lean.
    setItems([]);
    setCursor(null);
    await load(true);
  };

  useEffect(() => {
    // Telegram MainButton: panel purchase must not stick between tabs.
    if (!tg_id) {
      telegramMainButtonSet({ text: "", show: false });
      return () => undefined;
    }

    telegramMainButtonSet({
      text: t("panels.buy_panel"),
      enabled: true,
      show: true,
    });

    const onClick = async () => {
      hapticImpact(settings.haptics_enabled);
      await buyPanel();
    };

    const off = telegramMainButtonOnClick(onClick);

    return () => {
      off();
      telegramMainButtonSet({ text: "", show: false });
    };
  }, [tg_id, t, settings.haptics_enabled, buyPanel]);

  if (!tg_id) {
    return (
      <Card title={t("panels.title")}>
        <div className={`text-sm text-[var(--tg-hint)]
        `}>{td("desc.common.need_telegram_webapp")}</div>
      </Card>
    );
  }

  return (
    <div className="grid gap-4">
      <Card title={t("panels.title")}>
        <div className="grid gap-3">
          <div>
            <div className={`text-sm efhc-text-muted
            `}>{t("panels.subtitle_price_100")}</div>
            <div className={`text-xs efhc-text-muted2 mt-1
            `}>{td("desc.panels.lotteries_hint")}</div>
          </div>

          <div className="grid grid-cols-2 gap-2">
            <Button onClick={buyPanel}>{t("panels.buy_panel")}</Button>
            <Button
              variant="secondary"
              onClick={() => {
                globalThis.location.href = "/lotteries";
              }}
            >
              {t("nav.lotteries")}
            </Button>
            <Button
              variant={tab === "active" ? "primary" : "secondary"}
              onClick={() => setTab("active")}
            >
              {t("panels.tab_active")}
            </Button>
            <Button
              variant={tab === "archive" ? "primary" : "secondary"}
              onClick={() => setTab("archive")}
            >
              {t("panels.tab_archive")}
            </Button>
          </div>
        </div>
      </Card>

      <div className="grid md:grid-cols-3 gap-4">
        <Card title={t("panels.summary")}>
          <div className="text-xs efhc-text-muted2">
            {t("panels.active_count")}
          </div>
          <div className="text-2xl font-bold tabular-nums">
            {activePanels ?? "—"}
          </div>

          <div className="mt-2 text-xs efhc-text-muted2">
            {t("panels.effective_rate")}
          </div>
          <div className="text-xl font-semibold tabular-nums">
            {genPerSecEffective === null
              ? "—"
              : format8(genPerSecEffective)}{" "}
            kWh/sec
          </div>

          <div className="mt-2 text-xs efhc-text-muted2">
            {t("panels.nearest_expire")}
          </div>
          <div className="text-sm">
            {summary?.nearest_expire_at ?? "—"}
          </div>
        </Card>

        <Card title={t("panels.gen_rate")}>
          <div className="grid gap-2">
            {genPerSecBase !== null ? (
              <div>
                <div className="text-xs efhc-text-muted2">
                  {t("panels.base_rate")}
                </div>
                <div className="text-sm tabular-nums">
                  {format8(genPerSecBase)} kWh/sec
                </div>
              </div>
            ) : null}

            {genPerSecVip !== null ? (
              <div>
                <div className="text-xs efhc-text-muted2">
                  {t("panels.vip_rate")}
                </div>
                <div className="text-sm tabular-nums">
                  {format8(genPerSecVip)} kWh/sec
                </div>
              </div>
            ) : null}

            <div>
              <div className="text-xs efhc-text-muted2">
                {t("panels.effective_rate")}
              </div>
              <div className="text-xl font-semibold tabular-nums">
                {genPerSecEffective === null
                  ? "—"
                  : format8(genPerSecEffective)}{" "}
                kWh/sec
              </div>
            </div>

            {isVip ? <Badge>VIP</Badge> : null}
          </div>
        </Card>

        <Card title={t("panels.lotteries_cta")}>
          <div className={`text-sm text-[var(--tg-hint)]
          `}>{td("desc.panels.lotteries_hint")}</div>
          <div className="mt-3">
            <a
              className="underline"
              href="/lotteries">{t("nav.lotteries")}</a
            >
          </div>
        </Card>
      </div>

      <Card
        title={t(
          tab === "active"
            ? "panels.tab_active"
            : "panels.tab_archive",
        )}
      >
        <div className="flex gap-2 mb-3">
          <Button
            variant={tab === "active" ? "primary" : "secondary"}
            onClick={() => setTab("active")}
          >
            {t("panels.tab_active")}
          </Button>
          <Button
            variant={tab === "archive" ? "primary" : "secondary"}
            onClick={() => setTab("archive")}
          >
            {t("panels.tab_archive")}
          </Button>
        </div>

        <div className="grid gap-2">
          {items.map((p) => {
            const activatedIso = p.activated_at ?? p.created_at ?? null;
            const expiresIso = p.expires_at ?? p.archived_at ?? null;
            const expiresMs = expiresIso ?
              Date.parse(expiresIso)
              : null;
            const rem =
              tab === "active" && p.is_active && nowUtcMs !== null &&
                expiresMs !== null && !Number.isNaN(expiresMs)
                ? (expiresMs - nowUtcMs) / 1_000
                : null;

            return (
              <div
                key={p.id}
                className={
                  "rounded-2xl p-3 " +
                  "bg-[var(--tg-secondary-bg)] " +
                  "border border-[color:var(--tg-hint)]"
                }
              >
                <div className="flex items-center justify-between">
                  <div className="font-semibold tabular-nums">
                    {p.public_id ? p.public_id : "—"}
                  </div>
                  {p.is_active ? (
                    <Badge>{t("panels.active")}</Badge>
                  ) : (
                    <Badge>{t("panels.archived")}</Badge>
                  )}
                </div>
                <div className="mt-2 grid grid-cols-2 gap-2 text-sm">
                  <div>
                    <div className={`text-xs efhc-text-muted2
                    `}>{t("panels.created_at")}</div>
                    <div className="tabular-nums">
                      {formatUtcMinute(activatedIso)}
                    </div>
                  </div>
                  <div>
                    <div className={`text-xs efhc-text-muted2
                    `}>{t("panels.expires_at")}</div>
                    <div className="tabular-nums">
                      {formatUtcMinute(expiresIso)}
                    </div>
                  </div>
                  <div>
                    <div className={`text-xs efhc-text-muted2
                    `}>{t("panels.base_gen_per_sec")}</div>
                    <div className="tabular-nums">
                      {format8(p.base_gen_per_sec)}
                    </div>
                  </div>
                  <div>
                    <div className={`text-xs efhc-text-muted2
                    `}>{t("panels.generated_kwh")}</div>
                    <div className="tabular-nums">
                      {format8(p.generated_kwh)}
                    </div>
                  </div>

                  <div className="col-span-2">
                    <div className={`text-xs efhc-text-muted2
                    `}>{t("panels.remaining")}</div>
                    <div className="tabular-nums">
                      {tab === "active" && p.is_active
                        ? formatRemaining(rem)
                        : "—"}
                    </div>
                  </div>
                </div>
              </div>
            );
          })}

          {loading && items.length === 0 ? (
            <div className="grid gap-2">
              <Skeleton className="h-24" />
              <Skeleton className="h-24" />
            </div>
          ) : null}

          {items.length === 0 && !loading ? (
            <EmptyState
              title={t("common.empty")}
              detail={err || td("desc.panels.lotteries_hint")}
              actionLabel={t("common.refresh")}
              onAction={() => load(true)}
            />
          ) : null}

          <div className="flex items-center gap-2 mt-2">
            {canLoadMore ? (
              <Button disabled={loading} onClick={() => load(false)}>
                {loading ? t("common.loading") : t("common.load_more")}
              </Button>
            ) : (
              <span className={`text-xs efhc-text-muted2
              `}>{t("common.end")}</span>
            )}
          </div>
        </div>
      </Card>
    </div>
  );
}