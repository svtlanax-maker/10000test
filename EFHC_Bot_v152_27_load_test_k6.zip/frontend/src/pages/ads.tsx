import { useEffect } from "react";
import { useRouter } from "next/router";

// Канон: отдельной страницы Ads нет. Всё в /tasks.
// Этот файл оставлен только ради обратной совместимости старых ссылок.
export default function AdsRedirect() {
  const r = useRouter();
  useEffect(() => {
    r.replace("/tasks");
  }, [r]);
  return null;
}
