import React, { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { Card } from "../../components/ui/Card";
import { Button } from "../../components/ui/Button";
import { apiRequest } from "../../lib/api";
import { newIdempotencyKey } from "../../lib/idempotency";
import { useT } from "../../hooks/useT";
import { format8 } from "../../lib/format";

type BankBalance = {
  tg_id: number;
  efhc_balance: string;
};

export default function AdminBankPage() {
  const t = useT();
  const [bal, setBal] = useState<BankBalance | null>(null);
  const [msg, setMsg] = useState<string | null>(null);
  const [amount, setAmount] = useState<string>("100.00000000");
  const [reason, setReason] = useState<string>("");

  const load = async () => {
    setMsg(null);
    try {
      const r = await apiRequest<BankBalance>(
        `/admin/bank/balance`,
        "GET",
      );
      setBal(r);
    } catch (e: any) {
      setBal(null);
      setMsg(String(e?.message || e));
    }
  };

  useEffect(() => { load(); }, []);

  const onAmountChange = (
    e: React.ChangeEvent<HTMLInputElement>,
  ) => setAmount(e.target.value);

  const onReasonChange = (
    e: React.ChangeEvent<HTMLInputElement>,
  ) => setReason(e.target.value);

  const doMintBurn = async (mode: "mint" | "burn") => {
    setMsg(null);
    try {
      const idk = newIdempotencyKey();
      const r = await apiRequest<any>(`/admin/bank/${mode}`, "POST", {
        idempotencyKey: idk,
        body: { amount, reason, idempotency_key: idk },
      });
      setMsg(JSON.stringify(r, null, 2));
      await load();
    } catch (e: any) {
      setMsg(String(e?.message || e));
    }
  };

  return (
    <div className="grid gap-4">
      <div className="flex items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold">{t("admin.bank")}</h1>
          <div className="text-xs text-[color:var(--tg-hint)]">
            {t("admin.bank_note")}
          </div>
        </div>
        <Link href="/admin">
          <Button variant="secondary">
            {t("common.back")}
          </Button>
        </Link>
      </div>

      {msg ? (
        <Card title={t("common.status")}>
          <pre className="text-xs whitespace-pre-wrap">{msg}</pre>
        </Card>
      ) : null}

      <Card title={t("admin.bank_balance")}
        >
        <div className="text-sm">
          {bal ? (
            <div className="grid gap-1">
              <div>{t("admin.bank_tid")}: <b>{bal.tg_id}</b></div>
              <div>
                {t("admin.bank_efhc")}: 
                <b className="tabular-nums">
                  {format8(bal.efhc_balance)}
                </b>
              </div>
            </div>
          ) : (
            <div className="text-[color:var(--tg-hint)]">
              {t("admin.no_balance")}
            </div>
          )}
        </div>
        <div className="mt-3">
          <Button onClick={load}>{t("common.refresh")}</Button>
        </div>
      </Card>

      <Card title={t("admin.emission")}
        >
        <div className="grid gap-2">
          <div className="grid gap-1">
            <div className="text-xs text-[color:var(--tg-hint)]">
              {t("admin.amount_d8")}
            </div>
            <input
              className="w-full efhc-input"
              value={amount}
              onChange={onAmountChange}
              placeholder="0.00000000"
            />
          </div>
          <div className="grid gap-1">
            <div className="text-xs text-[color:var(--tg-hint)]">
              {t("admin.reason")}
            </div>
            <input
              className="w-full efhc-input"
              value={reason}
              onChange={onReasonChange}
              placeholder={t("admin.reason_ph")}
            />
          </div>
          <div className="flex gap-2">
            <Button onClick={() => doMintBurn("mint")}>
              {t("admin.mint")}
            </Button>
            <Button
              variant="secondary"
              onClick={() => doMintBurn("burn")}
            >
              {t("admin.burn")}
            </Button>
          </div>
          <div className="text-xs text-[color:var(--tg-hint)]">
            {t("admin.idk_required")}
          </div>
        </div>
      </Card>
    </div>
  );
}
