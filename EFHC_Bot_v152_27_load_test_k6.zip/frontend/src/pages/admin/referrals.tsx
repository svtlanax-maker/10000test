import React, { useEffect, useState } from "react";
import Link from "next/link";
import { Card } from "../../components/ui/Card";
import { Button } from "../../components/ui/Button";
import { useT } from "../../hooks/useT";
import { apiRequest } from "../../lib/api";

function newIdk(prefix: string) {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const c: any = globalThis.crypto;
  const uuid = c?.randomUUID ?
    c.randomUUID()
    : `${Date.now()}-${Math.random()}`;
  return `${prefix}:${uuid}`;
}

export default function AdminReferralsPage() {
  const t = useT();
  const [summary, setSummary] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function load() {
    setLoading(true);
    setError(null);
    try {
      const res = await apiRequest<any>(
        "/api/admin/referrals/summary?limit=100",
        "GET",
      );
      setSummary(res);
    } catch (e: any) {
      setError(e?.message || String(e));
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
  }, []);

  async function manualBonus() {
    const tg = prompt(t("admin.tg_id_prompt") || "Telegram ID")?.trim();
    const amount = prompt(t("admin.amount_prompt") || "Amount")?.trim();
    const reason = prompt(t("admin.reason_prompt") || "Reason")?.trim();
    if (!tg || !amount || !reason) return;
    setLoading(true);
    setError(null);
    try {
      await apiRequest<any>(
        "/api/admin/referrals/manual-bonus",
        "POST",
        {
          idempotencyKey: newIdk(`admin-ref-bonus-${tg}`),
          body: {
            tg_id: Number(tg),
            amount_efhc: amount,
            reason,
          },
        },
      );
      await load();
    } catch (e: any) {
      setError(e?.message || String(e));
    } finally {
      setLoading(false);
    }
  }

  async function reassign() {
    const tg = prompt(
      t("admin.child_tg_id_prompt") ||
        "Child telegram id",
    )?.trim();
    const parent = prompt(
      t("admin.parent_tg_id_prompt") ||
        "New parent telegram id",
    )?.trim();
    if (!tg || !parent) return;
    setLoading(true);
    setError(null);
    try {
      await apiRequest<any>("/api/admin/referrals/reassign", "POST", {
        idempotencyKey: newIdk(`admin-ref-reassign-${tg}`),
        body: {
          child_tg_id: Number(tg),
          new_parent_tg_id: Number(parent),
        },
      });
      await load();
    } catch (e: any) {
      setError(e?.message || String(e));
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="grid gap-4">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">{t("admin.referrals")}</h1>
        <Link href="/admin">
          <Button className="bg-white text-black">
            {t("admin.back")}
          </Button>
        </Link>
      </div>

      <Card title={t("admin.referrals_summary")}
      >
        <div className="flex items-center gap-2 mb-3">
          <Button
            className="bg-white text-black"
            onClick={load}
            disabled={loading}
          >
            {loading ? t("common.loading") : t("common.refresh")}
          </Button>
          <Button
            className="bg-white text-black"
            onClick={manualBonus}
            disabled={loading}
          >
            {t("admin.manual_bonus")}
          </Button>
          <Button
            className="bg-white text-black"
            onClick={reassign}
            disabled={loading}
          >
            {t("admin.reassign")}
          </Button>
        </div>

        {error ? (
          <div className="text-sm text-red-500 mb-2">
            {error}
          </div>
        ) : null}

        <pre
          className={
            "text-xs whitespace-pre-wrap break-words " +
            "bg-black/10 rounded p-2"
          }
        >
          {summary ? (
            JSON.stringify(summary, null, 2)
          ) : (
            t("common.loading")
          )}
        </pre>
      </Card>
    </div>
  );
}
