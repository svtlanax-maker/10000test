import React, { useEffect, useState } from "react";
import Link from "next/link";
import { Card } from "../../components/ui/Card";
import { Button } from "../../components/ui/Button";
import { useT } from "../../hooks/useT";
import { apiRequest } from "../../lib/api";

type TransferLogItem = {
  id: number;
  tg_id: number;
  amount: string;
  direction: string;
  balance_type: string;
  reason: string;
  idempotency_key: string;
  meta?: any;
  created_at: string;
};

type TransferLogsOut = {
  ok: boolean;
  items: TransferLogItem[];
  next_cursor?: string | null;
};

export default function AdminLogsPage() {
  const t = useT();
  const [tg_id, set_tg_id] = useState<string>("");
  const [reason, setReason] = useState<string>("");
  const [items, setItems] = useState<TransferLogItem[]>([]);
  const [cursor, setCursor] = useState<string | null>(null);
  const [nextCursor, setNextCursor] = useState<string | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [err, setErr] = useState<string>("");

  const input_class =
    "rounded-xl border border-white/10 bg-white/5 " +
    "px-3 py-2 text-sm outline-none";

  async function load(reset: boolean) {
    setLoading(true);
    setErr("");
    try {
      const params = new URLSearchParams();
      if (tg_id.trim()) params.set("tg_id", tg_id.trim());
      if (reason.trim()) params.set("reason", reason.trim());
      params.set("limit", "100");
      if (!reset && cursor) params.set("cursor", cursor);
      const url = `/admin/logs/transfers?${params.toString()}`;
      const data = await apiRequest<TransferLogsOut>(url, "GET");
      if (reset) {
        setItems(data.items || []);
      } else {
        setItems((prev) => [...prev, ...(data.items || [])]);
      }
      setNextCursor(data.next_cursor || null);
    } catch (e: any) {
      setErr(String(e?.message || e));
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    // initial
    setCursor(null);
    void load(true);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const canMore = Boolean(nextCursor);

  return (
    <div className="grid gap-4">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">{t("admin.logs")}</h1>
        <Link href="/admin">
          <Button className="bg-white text-black">
            {t("admin.back")}
          </Button>
        </Link>
      </div>

      <Card title={t("admin.logs")}>
        <div className="grid gap-3">
          <div className="grid gap-2 md:grid-cols-3">
            <input
              className={input_class}
              placeholder="tg_id (optional)"
              value={tg_id}
              onChange={(e) => set_tg_id(e.target.value)}
            />
            <input
              className={input_class}
              placeholder="reason (optional)"
              value={reason}
              onChange={(e) => setReason(e.target.value)}
            />
            <Button
              className="bg-white text-black"
              onClick={() => {
                setCursor(null);
                void load(true);
              }}
            >
              Refresh
            </Button>
          </div>

          {err ? (
            <div className="text-sm text-red-400">{err}</div>
          ) : null}
          {loading ? (
            <div className="text-sm text-gray-400">Loading…</div>
          ) : null}

          <div
            className="overflow-auto rounded-xl border border-white/10"
          >
            <table className="w-full text-left text-sm">
              <thead className="bg-white/5 text-xs text-gray-400">
                <tr>
                  <th className="px-3 py-2">Time</th>
                  <th className="px-3 py-2">tg_id</th>
                  <th className="px-3 py-2">Amount</th>
                  <th className="px-3 py-2">Type</th>
                  <th className="px-3 py-2">Direction</th>
                  <th className="px-3 py-2">Reason</th>
                  <th className="px-3 py-2">Idempotency</th>
                </tr>
              </thead>
              <tbody>
                {items.map((x) => (
                  <tr key={x.id} className="border-t border-white/10">
                    <td className="px-3 py-2 text-xs">
                      {new Date(x.created_at).toLocaleString()}
                    </td>
                    <td className="px-3 py-2 font-mono text-xs">
                      {x.tg_id}
                    </td>
                    <td className="px-3 py-2 font-mono text-xs">
                      {x.amount}
                    </td>
                    <td className="px-3 py-2 text-xs">
                      {x.balance_type}
                    </td>
                    <td className="px-3 py-2 text-xs">{x.direction}</td>
                    <td className="px-3 py-2 text-xs">{x.reason}</td>
                    <td
                      className={
                        "px-3 py-2 font-mono text-[10px] " +
                        "break-all"
                      }
                    >
                      {x.idempotency_key}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="flex items-center gap-2">
            <Button
              disabled={!canMore || loading}
              onClick={() => {
                if (!nextCursor) return;
                setCursor(nextCursor);
                void load(false);
              }}
            >
              Load more
            </Button>
            <div className="text-xs text-gray-500">
              Cursor pagination via cursor_codec SSOT.
            </div>
          </div>
        </div>
      </Card>
    </div>
  );
}
