# BANK DEFICIT RUNBOOK (SSOT)

## Что такое дефицит банка
Дефицит банка EFHC — ситуация, когда **банк EFHC** (центральный баланс)
не может покрыть обязательства:
- реферальные начисления,
- начисления за покупки в Shop,
- любые операции, где источник — bank.

Канон: банк — **единый источник** для перечисленных операций.

---

## Symptoms
- Операции начисления падают с ошибкой "insufficient bank balance".
- В дашборде отрицательный/слишком маленький bank balance.
- Очередь начислений накапливается.

---

## Checks

### 1) Сверка bank balance и логов
```sql
SELECT * FROM efhc_core.bank_balances WHERE bank_key='EFHC_BANK' LIMIT
1;

SELECT id, created_at, op_type, amount, balance_after, details
FROM efhc_core.bank_logs
ORDER BY id DESC
LIMIT 200;
```

### 2) Найти основные «пожиратели» банка за период
```sql
SELECT op_type, SUM(amount) AS sum_amount
FROM efhc_core.bank_logs
WHERE created_at >= NOW() - INTERVAL '7 days'
GROUP BY op_type
ORDER BY SUM(amount) ASC;
```

### 3) Проверить массовые источники:
- Shop (покупки)
- Referrals (бонусы)
- Admin manual operations

---

## Actions

### A) Немедленная стабилизация
1) **Остановить** источники расхода (если предусмотрены тумблеры):
   - авто-выплаты/авто-награды (если есть)
2) **Зафиксировать** момент (время) и снимок данных:
   - bank_balances
   - последние 1000 bank_logs

### B) Восстановление банка
Канонично — через **mint_efhc** (если это предусмотрено правилами
проекта) или через приток средств, который мапится на банк.
- Любой mint/burn/transfer должен быть:
  - идемпотентным (Idempotency-Key)
  - с admin log
  - с чётким reason

### C) Устранение первопричины
Типовые причины:
1) Отсутствие MUST Idempotency-Key → двойные списания.
2) Несогласованный контракт routes↔services → повторная обработка.
3) Отсутствие external-event dedupe → повторные webhooks.

Лечение:
- SSOT (canon_rules.yaml) + guard + тест.

---

## Rollback
- Все корректировки проводить через сервисные команды (не SQL руками).
- Если была двойная операция — делать refund/корректировку через
- transactions_service.

---

## Postmortem
- Добавить регрессионный тест на конкретный сценарий.
- Внести новые MUST пути/EXTERNAL пути в `ops/canon_rules.yaml`.
- Обновить runbook, чтобы следующий раз занимал минуты.
