# Incidents

1) Проверить /health
2) Проверить логи Vercel
3) Проверить блокировки (advisory locks)
4) При необходимости запустить recon_ton.py
