# SSOT: схемы и таблицы EFHC Bot (истина)

Этот документ — **источник истины** по физической схеме БД для EFHC Bot.

## Схемы (ровно 2)

- `efhc_core` — основная схема приложения (все пользовательские/игровые данные).
- `efhc_admin` — админская схема (служебные и управленческие таблицы).

## Таблицы (ровно 30)

### efhc_core (26)
- `users`
- `wallet_bindings`
- `withdraw_requests`
- `withdrawals`
- `panels`
- `achievements`
- `efhc_transfers_log`
- `ton_inbox_logs`
- `shop_orders`
- `shop_items`
- `ads`
- `tasks`
- `task_submissions`
- `app_settings`
- `bank_state`
- `idempotency_key`
- `referral_links`
- `ranks_snapshots`
- `ranks_top_cache`
- `user_skins`
- `user_cosmetics`
- `lotteries`
- `lotteries_tickets`
- `lotteries_results`
- `lotteries_user_stats`
- `lotteries_nft_claims`

### efhc_admin (4)
- `admin_action_log`
- `admin_bank_config`
- `admin_role`
- `admin_whitelist`

## Обязательная проверка (CI / Alembic sanity)

После `alembic upgrade head` должны существовать **все** `schema.table` из списка выше.
Проверка выполняется через `SELECT to_regclass('schema.table')`.
