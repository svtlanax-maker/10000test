# SSOT: Panels

## 0) Канон и замки (MUST)

1) Истина проекта — SSOT/канон.

2) Идентификатор пользователя — только `tg_id` (snake_case).

3) Запрещённые токены/подстроки из канона проекта нельзя
   использовать ни в коде, ни в документах, ни в примерах.
   В документации описываем запреты смыслом, без буквального
   написания запрещённых токенов.

4) Никаких новых алиасов/дублирующих эндпоинтов вне канонического API.

5) Числа/балансы: `Decimal(scale=8)`, округление **DOWN**,
   без scientific notation.

6) `Idempotency-Key` обязателен для операций создания панели
   (покупка) и любых повторяемых операций.

7) Аудит обязателен: попытка/результат,
   включая replay по идемпотентности.

8) Экономические замки проекта сохраняются:
   lifetime-счётчики не уменьшаются; зеркальные расчёты
   обменника не затрагиваются этим SSOT.

---

## 1) Цель

Сделать вкладку **Panels** каноничной и завершённой:

- Пользователь видит описание механики панелей.
- Пользователь может купить панель (если предусмотрено) — идемпотентно.
- Страница содержит вход в **Lotteries** только через кнопку
  на Panels (в нижней навигации отдельного пункта нет).
- Есть переключатель **Active / Archive** (Variant A),
  который показывает один список ниже.
- Каждая панель — отдельная запись, привязана к `tg_id`,
  имеет глобальный `public_id` формата `ID########`, даты
  `activated_at`, `expires_at`, статус и таймер “Осталось”.
- Срок жизни панели: **180 дней** от `activated_at` в UTC.
- UI таймер “Осталось” синхронизирован с `server_now_utc`.

---

## 2) SSOT-модель панелей (логика и время)

### 2.1 Дата активации и срок

- Дата покупки = дата активации: используем только `activated_at`.
- `expires_at = activated_at + 180 days` (UTC).
- Панель активна, если: `server_now_utc < expires_at`.
- Панель архивная, если: `server_now_utc >= expires_at`.

### 2.2 Таймер “Осталось”

Только UI.

**MUST:** UI не использует локальные часы устройства как истину времени.

**MUST:** `server_now_utc` (или `server_now_iso`) —
обязательная опорная точка; локальные часы используются
только как секундомер.

Формула:

- `remaining_seconds = max(0, expires_at - now_utc)`
- `now_utc = server_now_utc + (client_now - client_received_at)`

UI формат:

- `Осталось: {days}д {hours}ч {mins}м`

### 2.3 Глобальный ID панелей

ID панелей нумеруются глобально по всему боту и всем пользователям.

Используется DB sequence / auto-increment (BIGSERIAL).

Публичный ID:

- `public_id = "ID" + zfill(id, 8)`

Пример:

- `ID00000001`

Примечание: sequence может иметь пропуски при rollback/crash.
Это нормально. Требование “не создать новую панель при повторе
одного запроса” обеспечивается идемпотентностью покупки.

---

## 3) База данных: схема и миграции (Alembic)

### 3.1 Таблица `panels` (новая или приведение существующей)

`panels`

- `id BIGSERIAL PRIMARY KEY` — глобальный автоинкремент
  (источник для `public_id`)
- `tg_id BIGINT NOT NULL` — владелец панели
- `public_id TEXT UNIQUE` — глобальный публичный ID
  (до заполнения допускается NULL)
- `activated_at TIMESTAMPTZ NOT NULL DEFAULT now()` — UTC
- `expires_at TIMESTAMPTZ NOT NULL` —
  `activated_at + interval '180 days'`
- `created_at TIMESTAMPTZ NOT NULL DEFAULT now()`

Индексы:

- `CREATE INDEX panels_tg_id_idx ON panels (tg_id);`

CHECK (Postgres):

- `expires_at > activated_at`

### 3.2 Идемпотентность покупки панели (техническая таблица)

Если в проекте уже есть общий механизм хранения
идемпотентности — использовать его.

Если нет — добавить техническую таблицу:

`panel_issuance`

- `id BIGSERIAL PRIMARY KEY`
- `tg_id BIGINT NOT NULL`
- `idempotency_key TEXT NOT NULL`
- `panel_id BIGINT NOT NULL REFERENCES panels(id)`
- `created_at TIMESTAMPTZ NOT NULL DEFAULT now()`

Constraints:

- `UNIQUE (tg_id, idempotency_key)`
- (опционально) `UNIQUE (panel_id)`

Индекс:

- `INDEX panel_issuance_tg_id_idx (tg_id)`

### 3.3 Миграции Alembic (план)

Migration A: `create_panels_table`

- create table `panels`
- add index `panels_tg_id_idx`
- add UNIQUE на `public_id`
- add CHECK `expires_at > activated_at`

Migration B: `create_panel_issuance_table`

- create table `panel_issuance`
- add UNIQUE `(tg_id, idempotency_key)`
- add FK to `panels(id)`

### 3.4 Генерация `public_id`

**Канон:** `public_id` при INSERT должен быть **NULL**,
а заполняется сразу после получения `id` в той же транзакции.

В схеме: `public_id TEXT UNIQUE` и разрешить NULL до заполнения
(Postgres допускает множественные NULL в UNIQUE).

Алгоритм:

1) INSERT и получение id:

```sql
INSERT INTO panels(
  tg_id, public_id, activated_at, expires_at
) VALUES (
  :tg_id, NULL, :activated_at, :expires_at
) RETURNING id;
```

2) `public_id = "ID" + zfill(id, 8)`

3) Обновление public_id:

```sql
UPDATE panels SET public_id = :public_id WHERE id = :id;
```

---

## 4) Backend: сервис генерации панелей (SSOT)

### 4.1 Контракт сервиса (MUST)

`create_panel_for_user(tg_id: int, idempotency_key: str) -> PanelDTO`

Требования:

- атомарно (транзакция)
- idempotent replay: повтор возвращает тот же `panel_id/public_id`
- пишет аудит attempt/result

### 4.2 Create — алгоритм (строго)

**MUST (Idempotency invariants):**

- Один `(tg_id, Idempotency-Key)` всегда возвращает
  одну и ту же панель: `panel_id` и `public_id` неизменны.
- При replay сервис не создаёт новую запись `panels` и
  не берёт новый sequence `id`.
- Audit фиксирует `status="replay"`.

В одной транзакции:

1) Replay check:

```sql
SELECT panel_id
FROM panel_issuance
WHERE tg_id = :tg_id
  AND idempotency_key = :key;
```

- если найдено → вернуть панель (replay)

2) Create panel:

- `activated_at = now_utc()`
- `expires_at = activated_at + 180 days`
- INSERT/UPDATE public_id выполняется по канону раздела 3.4.

3) Bind idempotency:

```sql
INSERT INTO panel_issuance(
  tg_id, idempotency_key, panel_id
) VALUES (
  :tg_id, :key, :panel_id
);
```

4) Audit (см. раздел 6)

5) Commit и вернуть DTO.

### 4.3 Сервис выборки списков

`list_user_panels(
  tg_id, kind: "active"|"archive", limit, cursor,
  server_now_utc
) -> list[PanelDTO]`

Фильтры должны зависеть только от `:server_now_utc` (без `now()` БД):

- Active: `expires_at > :server_now_utc`
- Archive: `expires_at <= :server_now_utc`

Причина: одинаковое поведение в Postgres/SQLite и отсутствие дрейфа.

Сортировка:

- `activated_at DESC` (или `id DESC` — допускается)

---

## 5) API (без алиасов)

### 5.1 Страница Panels должна получать

- список Active или Archive панелей (по переключателю)
- `server_now_utc` (как часть снапшота или отдельного ответа)

Если в проекте уже есть snapshot с
`server_now_iso`/`server_now_utc` — использовать его.

### 5.2 Операция покупки панели

Если каноничный endpoint покупки панелей уже существует —
использовать **только его**.

Если его нет — допускается добавить ровно один каноничный endpoint:

- `POST /panels/buy/{tg_id}`

Headers:

- `Idempotency-Key: <uuid>`

Body:

- пустой (покупка = активация, 1 панель)

Response:

- созданная панель (PanelDTO)
- `server_now_utc`

**MUST NOT:** любые вторые маршруты,
альтернативные endpoints или алиасы покупки панели.

---

## 6) Аудит (MUST)

### 6.1 PANEL_CREATE audit extra_info

Пишется всегда: `success`, `replay`, `error`.

Поля:

- `audit_schema_version: "v1"`
- `tg_id`
- `op_type: "PANEL_CREATE"`
- `idempotency_key`
- `panel_id`
- `panel_public_id`
- `activated_at`
- `expires_at`
- `status: success | replay | error`
- `reason` (для error)

---

## 7) UI: структура страницы Panels (строго)

### 7.1 Верхний блок “Описание”

- краткий текст о панелях и генерации
- цена панели (если в каноне): 100 EFHC
- без лишних обещаний

### 7.2 Блок действий

Кнопки 2×2:

1) Купить панель

2) Lotteries (переход)

3) Active

4) Archive

Active/Archive управляют одним списком ниже.

### 7.3 Список панелей (один, переключаемый)

Карточка панели (MUST):

- `public_id` (пример: `ID00000001`)
- `activated_at` (формат до минут)
- `expires_at` (формат до минут)
- `Осталось: 179д 23ч 59м` (для Active; для Archive
  можно не показывать или `0д 0ч 0м`)
- Статус: Active/Archive по `server_now_utc < expires_at`
- Описание: коротко

Формат дат:

- `DD.MM.YYYY HH:MM (UTC)` без секунд.

---

## 8) Тесты (pytest + статические guards)

### 8.1 Backend tests (MUST)

1) Idempotency create panel:

- два вызова покупки/создания с одним ключом → одна и
  та же панель (`panel_id`, `public_id` одинаковы)

2) Global ID ordering:

- создать панель для `tg_id` A, затем для `tg_id` B →
  `id` глобально растёт; `public_id` различны и корректны

3) 180 days:

- `expires_at - activated_at == 180 days` (UTC)

4) Active/Archive classification:

- если `server_now_utc < expires_at` → Active
- иначе Archive

### 8.2 Static guard tests (SHOULD)

- запрет локального ручного форматирования чисел/дат
  в Panels UI при наличии общего форматтера.

---

## 9) Definition of Done

Готово, если:

1) В БД есть таблица `panels` с глобальным auto-increment и
   `public_id` формата `ID########` (уникальная по всему боту).

2) Покупка панели идемпотентна: повтор не создаёт
   новую панель и возвращает ту же.

3) У панели есть `activated_at` и
   `expires_at = activated_at + 180 days` (UTC).

4) UI Panels показывает: описание + кнопки (Купить панель,
   Lotteries), переключатель Active/Archive, один список
   ниже, карточки с ID/датами до минут, “Осталось”, статус.

5) Таймер “Осталось” синхронизирован с `server_now_utc`.

6) Тесты PASS: idempotency, global id, 180 days, active/archive.

7) Канон запретов соблюдён: нет запрещённых токенов,
   нет неканоничных идентификаторов; нет алиасов.
