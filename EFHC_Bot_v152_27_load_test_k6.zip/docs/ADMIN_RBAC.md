# ADMIN_RBAC (EFHC) — Роли и права админ-панели

Статус: NORM (нормативный документ прав доступа).
Якорь SSOT: docs/SSOT_INDEX.md

Цель: единая матрица ролей и разрешений для backend/admin API и UI.
Любые отличия кода/доков от этого документа считаются дефектом.

---

## 1. Термины

- RBAC — Role-Based Access Control (доступ по ролям).
- AdminRole — модель/перечисление роли администратора.
- require_role — проверка минимальной роли для админ-операции.
- role — роль (набор прав).
- permission — разрешение на операцию.
- admin_action — действие админа, которое обязано попасть в audit.
- audit_log — журнал аудита админ-действий.
- sensitive_operation — операция с повышенным риском.
- idempotency_key — ключ идемпотентности (обязателен для операций,
  изменяющих состояние и баланс).

---

## 2. Общие правила доступа

1) Разделение доступа
- user API — доступен только пользователю по tg_id.
- admin API — доступен только админам по tg_id.

2) Канон идентификатора
- Во всех админ-действиях и аудите используется только tg_id.

3) Аудит и идемпотентность
- Все sensitive_operation обязаны:
  - иметь audit_log запись,
  - требовать Idempotency-Key,
  - логировать tg_id исполнителя и цель (target tg_id/объект).

4) Принцип наименьших привилегий
- Роль получает только те права, которые нужны для задач.

---

## 3. Роли (каноничный набор)

Минимальный канон ролей:
- viewer — только просмотр (read-only).
- operator — операционные действия без изменения банка.
- finance — финансы (банк/корректировки/подтверждения покупок).
- auditor — аудит и отчёты (read-only + экспорт).
- admin — полный доступ (кроме супер-операций, если выделены).
- owner — владелец/суперадмин (включая смену критичных настроек).

Примечание:
- Если в текущем runtime нет ролевой модели, документ используется как
  целевое SSOT, а реализация вводится отдельной задачей.

---

## 4. Матрица прав (операции)

Легенда:
- R — read (просмотр)
- W — write (изменение)
- A — audit required (обязателен audit_log)
- I — idempotency required (обязателен Idempotency-Key)

Операции сгруппированы по подсистемам.

### 4.1. Пользователи

- Просмотр профиля пользователя
  - viewer: R
  - operator: R
  - finance: R
  - auditor: R
  - admin: R
  - owner: R

- Корректировка баланса пользователя (EFHC)
  - viewer: -
  - operator: -
  - finance: W A I
  - auditor: -
  - admin: W A I
  - owner: W A I

- Изменение статусов (VIP/NFT/ранг) вручную
  - viewer: -
  - operator: W A I
  - finance: W A I
  - auditor: -
  - admin: W A I
  - owner: W A I

### 4.2. EFHC Bank

- Просмотр баланса банка и журнала операций
  - viewer: R
  - operator: R
  - finance: R
  - auditor: R
  - admin: R
  - owner: R

- Ручная корректировка банка (bank_operation)
  - viewer: -
  - operator: -
  - finance: W A I
  - auditor: -
  - admin: W A I
  - owner: W A I

- Массовые операции банка
  - viewer: -
  - operator: -
  - finance: W A I
  - auditor: -
  - admin: W A I
  - owner: W A I
  Требование: отдельное подтверждение и отдельный audit.

### 4.3. Выводы (withdrawals)

- Просмотр очереди заявок
  - viewer: R
  - operator: R
  - finance: R
  - auditor: R
  - admin: R
  - owner: R

- Изменение статуса заявки (approve/reject/paid/error)
  - viewer: -
  - operator: W A I
  - finance: W A I
  - auditor: -
  - admin: W A I
  - owner: W A I

- Назначение приоритета (VIP priority)
  - viewer: -
  - operator: W A I
  - finance: W A I
  - auditor: -
  - admin: W A I
  - owner: W A I

### 4.4. Shop (покупки)

- Просмотр товаров и заказов
  - viewer: R
  - operator: R
  - finance: R
  - auditor: R
  - admin: R
  - owner: R

- Подтверждение покупки (после TON/USDT)
  - viewer: -
  - operator: W A I
  - finance: W A I
  - auditor: -
  - admin: W A I
  - owner: W A I

- Возврат/отмена (если предусмотрено)
  - viewer: -
  - operator: -
  - finance: W A I
  - auditor: -
  - admin: W A I
  - owner: W A I

### 4.5. Призы (подсистема lotteries)

Термины UI/доков: prizes (см. TERMS_GLOSSARY).
Кодовая подсистема: lotteries (если уже закреплено структурой).

- Просмотр событий/истории
  - viewer: R
  - operator: R
  - finance: R
  - auditor: R
  - admin: R
  - owner: R

- Админ-выдача приза / корректировка результатов
  - viewer: -
  - operator: W A I
  - finance: W A I
  - auditor: -
  - admin: W A I
  - owner: W A I

### 4.6. Логи, события, аудит

- Просмотр audit_log / events
  - viewer: R
  - operator: R
  - finance: R
  - auditor: R
  - admin: R
  - owner: R

- Экспорт отчётов
  - viewer: -
  - operator: -
  - finance: R
  - auditor: R
  - admin: R
  - owner: R

---

## 5. Требования к реализации (контроль)

1) Любой admin endpoint обязан иметь:
- required_role/permission (или эквивалентный guard),
- audit_log для W A операций,
- Idempotency-Key для W I операций.

2) Любая операция, влияющая на баланс:
- должна иметь reason + details (SSOT),
- должна быть атомарной.

3) Ошибки доступа
- Использовать единый формат ошибок:
  - error_code, message, details
  См. docs/ERROR_CODES.md.

---
