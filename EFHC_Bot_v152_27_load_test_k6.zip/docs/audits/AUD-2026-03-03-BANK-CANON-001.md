# AUD-2026-03-03-BANK-CANON-001

Статус: NORM.

## 0) Цель

Канонизация правил Банка EFHC:

- Банк может уходить в минус.
- Внутри системы нет «списания/пополнения».
  Есть только credit/debit между пользователем и банком.
- Эмиссия — крайний случай и меняет только банк.
- Внешний вход в TON-сети триггерит внутреннюю проводку 1:1.

## 1) Источники

- docs/EFHC_CANON.md
- docs/EXCHANGE_WITHDRAW_MECHANICS_SSOT.md
- backend/app/services/transactions_service.py
- backend/app/services/admin/admin_rbac.py
- backend/app/services/admin/admin_bank_service.py

## 2) Найденные расхождения и фиксы

### 2.1 Запрет минуса банка в transactions_service

Проблема:

- В коде был стоп-кран `Insufficient bank funds`.
- Это противоречит канону «банк может уходить в минус».

Фикс:

- Удалён запрет минуса банка.
- Сохранён запрет минуса пользователя.

Файл:

- backend/app/services/transactions_service.py

### 2.2 Виртуальный ROOT admin

Проблема:

- RBAC мог создавать «виртуального ROOT SuperAdmin».
- Это нарушает канон: админ только по whitelist.

Фикс:

- ROOT_ADMIN допускается только если есть запись в whitelist.
- Роль может быть повышена до SuperAdmin.

Файл:

- backend/app/services/admin/admin_rbac.py

### 2.3 Дубль-проверка whitelist в денежном admin_bank_service

Проблема:

- mint/burn в админ-банке были защищены RBAC-ролью,
  но без дубль-проверки whitelist внутри сервиса.

Фикс:

- Перед RBAC.require_role добавлен
  `RBAC.resolve_admin(db, admin.tg_id)`.

Файл:

- backend/app/services/admin/admin_bank_service.py

## 3) Документация

Внесено в канон:

- Банк может уходить в минус.
- Эмиссия меняет только банк.
- Внешний вход — триггер `user credit ⇒ bank debit`.

Файлы:

- docs/EFHC_CANON.md
- docs/EXCHANGE_WITHDRAW_MECHANICS_SSOT.md

## 4) Открытые вопросы

1) Хранение баланса банка:
   канон — system_balances/bank_balance по ключам EFHC_MAIN/EFHC_BONUS.
   В коде местами встречается модель «банк как tg_id».
   Нужен план миграции к единой системной таблице.

2) Контроль внешнего обеспечения:
   банк может быть отрицательным.
   Нужен отдельный отчёт о покрытии дефицита внешним обеспечением
   (без влияния на проводки).
