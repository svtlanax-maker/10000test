Audit-Id: AUD-2026-03-01-GUARDS-SSOT-002
Date: 2026-03-01
Version: EFHC_Bot_v149_20
Topic: guards-ssot
Status: ACTIVE
Superseded-By: null
Scope: Инвентаризация источников аудита и правила хранения evidence.
Sources:
  - type: DOC
    ref: docs/audits/_raw/AUD-2026-03-01-GUARDS-SSOT-002.pdf
Owner: Мастер
Confidence: MEDIUM

## Executive Summary

Зафиксирован источник "Инвентаризация источников аудита" и его место в
канонической системе docs/audits/. Этот аудит закрепляет правило: любой
аудит обязан ссылаться на первичный источник (PDF/лог/архив) через
docs/audits/_raw и audits_index.json.

## Findings (FACTS)

- В проекте используется SSOT-навигация audits_index.json, а первичные
  источники должны храниться в docs/audits/_raw. [[EV-001]]
- Отсутствие привязки к первичному источнику делает выводы аудита
  непроверяемыми при повторном аудите. [[EV-001]]

## Evidence Index

EV-001 | DOC | docs/audits/_raw/AUD-2026-03-01-GUARDS-SSOT-002.pdf | - |
PDF inventory of
audit sources | Доказывает перечень и подход к учёту источников аудита.

## Decisions (SSOT)

- Все audit-md обязаны иметь Sources с минимум 1 элементом и ссылкой на
  файл в docs/audits/_raw. [[EV-001]]
- Любые решения (особенно удаление/слияние/пересборка) допускаются
только
  при наличии evidence и ссылки в audits_index.json. [[EV-001]]

## Actions (P0/P1/P2)

### P0

- Проверить, что для каждого audit_id из audits_index.json существует
  files.raw, если в Sources указан DOC/PDF/LOG архив.
- Запретить ручное редактирование списка аудитов в README: только через
  генератор из JSON.

### P1

- Для крупных raw-дампов переносить извлечения в docs/audits/_raw, а в
  audit-md оставлять только 5–10 строк на пункт.

### P2

- Добавить в CI проверку "sources coverage": каждый change_cycle отчёт,
  который ссылается на аудит, должен упоминать Audit-Id.

## Impact & Risks

- Плюс: повторный аудит воспроизводим, ссылки на источники не теряются.
- Риск: рост размера репозитория из-за _raw; контролировать объём и
  хранить только нужные источники.

## Verification

- audits_index_lint: JSON валиден, связи консистентны.
- audits_md_lint: шапка/структура/EV-ссылки валидны.
- README соответствует генерации из audits_index.json.

## Appendix: Raw Extract (optional)

(пусто)

