Audit-Id: AUD-2026-02-28-ADMIN-SURFACE-002
Date: 2026-02-28
Version: EFHC_Bot_v149_16_add_registry_audits
Topic: admin-surface
Status: ACTIVE
Superseded-By: null
Scope: Инвентаризация schema-qualified RAW SQL (efhc_core/admin).
Sources: PDF: _raw/2026-02-28_admin-surface_v149_16__raw_sql.pdf
Owner: Мастер
Confidence: HIGH

## Executive Summary
Реестр schema-qualified RAW SQL: где и какие таблицы используются.

## Findings (FACTS)
- Всего RAW SQL: 4; OK_CORE: 3 (по PDF). [[EV-001]]
- Есть DYNAMIC_SQL через {SCHEMA}.users (по PDF). [[EV-001]]

## Evidence Index
EV-001 | DOC | see files.raw | - | see Appendix | PDF

## Decisions (SSOT)
- RAW SQL registry считать источником фактов о schema-qualified SQL.
- [[EV-001]]
- Новые RAW SQL должны попадать в реестр и проходить линт. [[EV-001]]

## Actions (P0/P1/P2)
### P0
- Запретить хардкод schema вне конфигурации. [[EV-001]]

### P1
- Сверить RAW SQL таблицы с ORM/0001. [[EV-001]]

### P2
- Расширить сбор RAW SQL registry в CI. [[EV-001]]

## Impact & Risks
- Реестр нужен для воспроизводимости аудита и привязки фактов к
доказательствам. [[EV-001]]

## Verification
- Сверить указанные file:line/сводные показатели с PDF и репозиторием.
  [[EV-001]]

## Appendix: Raw Extract (optional)
```text
Counts:
-
Всего
raw
SQL:
4
-
OK_CORE:
3
-
```
