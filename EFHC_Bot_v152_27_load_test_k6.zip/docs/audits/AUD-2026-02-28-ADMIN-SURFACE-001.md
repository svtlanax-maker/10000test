Audit-Id: AUD-2026-02-28-ADMIN-SURFACE-001
Date: 2026-02-28
Version: EFHC_Bot_v149_14
Topic: admin-surface
Status: ACTIVE
Superseded-By: null
Scope: Инвентаризация/аудит по теме; фиксация фактов и решений.
Sources:
  - DOC: docs/audits/_raw/AUD-2026-02-28-ADMIN-SURFACE-001.raw.md
Owner: Мастер
Confidence: MEDIUM

## Executive Summary

Свод: админ-сервисы используют efhc_admin через fallback; найден набор
fq-имён.

## Findings (FACTS)

- DB_SCHEMA_ADMIN отсутствует в ядре Settings [[EV-001]].
- Админ-сервисы используют efhc_admin через fallback/строки [[EV-002]].

## Evidence Index

EV-001 | CODE | backend/app/core/config_core.py | - | В Settings задан
только DB_SCHEMA_CORE; DB_SCHEMA_ADMIN отсутствует. | Админ-схема не
канонизирована в ядре.
EV-002 | CODE | backend/app/services/admin/** | - | Используются schema-
qualified обращения и fallback efhc_admin. | Админ-код зависит от
efhc_admin как строки.

## Decisions (SSOT)

- Схемы должны управляться только через Settings (ядро), без строковых
  fallback [[EV-001]] [[EV-002]].

## Actions (P0/P1/P2)

- P0: добавить DB_SCHEMA_ADMIN в Settings и заменить fallback на явный
  settings.DB_SCHEMA_ADMIN [[EV-001]] [[EV-002]].

## Impact & Risks

- Риск: плавающие схемы приводят к ошибкам to_regclass и несовпадениям в
  CI [[EV-002]].

## Verification

- Проверить: grep по коду не должен находить 'efhc_admin' вне конфига
  Settings [[EV-001]] [[EV-002]].

## Appendix: Raw Extract (optional)

See: /tmp/efhc_v149_14_1jfqo2i_/docs/audits/_raw/AUD-2026-02-28-ADMIN-
SURFACE-001.raw.md
