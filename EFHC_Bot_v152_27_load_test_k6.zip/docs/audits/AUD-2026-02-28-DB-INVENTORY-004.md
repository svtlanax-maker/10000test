Audit-Id: AUD-2026-02-28-DB-INVENTORY-004
Date: 2026-02-28
Version: EFHC_Bot_v149_16_add_registry_audits
Topic: db-inventory
Status: ACTIVE
Superseded-By: null
Scope: Реестр ORM-моделей с привязкой к файлам и строкам.
Sources: PDF: _raw/2026-02-28_db-inventory_v149_16__orm_reg.pdf
Owner: Мастер
Confidence: HIGH

## Executive Summary
Реестр ORM: перечисление моделей, schema.table и file:line.

## Findings (FACTS)
- Всего моделей: 31; schema.table: 31 (по PDF). [[EV-001]]
- Каждая запись содержит backend/app/models/*.py:line. [[EV-001]]
- schema=None для всех записей (по PDF). [[EV-001]]

## Evidence Index
EV-001 | DOC | see files.raw | - | see Appendix | PDF

## Decisions (SSOT)
- Использовать реестр для привязки дефектов к file:line. [[EV-001]]

## Actions (P0/P1/P2)
### P0
- При изменениях моделей обновлять реестр и аудит. [[EV-001]]

### P1
- Сверить модели с миграцией 0001 и устранить рассинхрон. [[EV-001]]

### P2
- Хранить сырой дамп в docs/audits/_raw. [[EV-001]]

## Impact & Risks
- Реестр нужен для воспроизводимости аудита и привязки фактов к
доказательствам. [[EV-001]]

## Verification
- Сверить указанные file:line/сводные показатели с PDF и репозиторием.
  [[EV-001]]

## Appendix: Raw Extract (optional)
```text
Counts:
-
Всего
моделей:
31
-
Уникальных
schema.table:
31
-
```
