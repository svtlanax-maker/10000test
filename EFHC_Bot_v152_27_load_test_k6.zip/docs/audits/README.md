# EFHC Audits

> AUTO-GENERATED from audits_index.json. Do not edit by hand.

## ACTIVE

| Audit-Id | Date | Topic | Scope-Key | Version | File | Summary |
|---|---|---|---|---|---|---|
| AUD-2026-02-28-ADMIN-SURFACE-001 | 2026-02-28 | admin-surface | admin-surface@db | EFHC_Bot_v149_14 | [md](docs/audits/2026-02-28_admin-surface_v149_14__admin_schema_refs.md) | Свод: админ-сервисы используют efhc_admin через fallback; найден набор fq-имён. |
| AUD-2026-02-28-ADMIN-SURFACE-002 | 2026-02-28 | admin-surface | admin-surface@raw-sql-registry | EFHC_Bot_v149_16_add_registry_audits | [md](docs/audits/2026-02-28_admin-surface_v149_16__raw_sql.md) | Реестр schema-qualified RAW SQL: где и какие таблицы используются. |
| AUD-2026-02-28-CI-FAILURES-001 | 2026-02-28 | ci-failures | ci-failures@alembic-import | EFHC_Bot_v149_14 | [md](docs/audits/2026-02-28_ci-failures_v149_14__alembic_import_backend.md) | Свод: ModuleNotFoundError 'backend' при запуске из extracted/backend. |
| AUD-2026-02-28-DB-INVENTORY-002 | 2026-02-28 | db-inventory | db-inventory@core-admin | v149_15 | [md](docs/audits/2026-02-28_db-inventory_v149_15__table_audit_2.md) | Устранены P0 дефекты: ReferralLink columns, ReferralBonusLedger, bank_balances, и ошибки 0001 (schema kw в Column, FK). |
| AUD-2026-02-28-DB-INVENTORY-005 | 2026-02-28 | db-inventory | db-inventory@duplicates-passport | EFHC_Bot_v149_17 | [md](docs/audits/2026-02-28_db-inventory_v149_17__duplicates_passport.md) | Проверка физ./логических дублей и внешних таблиц: конфликтов не выявлено. |
| AUD-2026-02-28-DB-INVENTORY-003 | 2026-02-28 | db-inventory | db-inventory@orm-models | EFHC_Bot_v149_16_add_registry_audits | [md](docs/audits/2026-02-28_db-inventory_v149_16__orm_inv.md) | Реестр ORM-моделей: schema.table, класс и file:line. |
| AUD-2026-02-28-DB-INVENTORY-004 | 2026-02-28 | db-inventory | db-inventory@orm-registry | EFHC_Bot_v149_16_add_registry_audits | [md](docs/audits/2026-02-28_db-inventory_v149_16__orm_reg.md) | Реестр ORM: перечисление моделей, schema.table и file:line. |
| AUD-2026-03-01-DB-INVENTORY-006 | 2026-03-01 | db-inventory | db-inventory@tables-schemas-search | EFHC_Bot_v149_22 | [md](docs/audits/2026-03-01_db-inventory_v149_22__tables_schemas_search.md) | Фиксация упоминаний дополнительных схем/таблиц вне миграций. |
| AUD-2026-02-28-DB-SSOT-001 | 2026-02-28 | db-ssot |  | EFHC_Bot_v149_18 | [md](docs/audits/2026-02-28_db-ssot_v149_18__schemas_core_admin.md) | Фиксирует допустимые схемы и запрет public; связывает канон таблиц с ORM и маршрутами. |
| AUD-2026-03-01-GUARDS-SSOT-003 | 2026-03-01 | guards-ssot | backend-clean | EFHC_Bot_v149_23 | [md](docs/audits/2026-03-01_guards-ssot_v149_23__backend_section_clean.md) | Фиксирует метод поиска таблиц/схем/маршрутов в backend и итоговые подсчёты. Основа для канонизации схем и запрета дрейфа именований. |
| AUD-2026-03-01-GUARDS-SSOT-002 | 2026-03-01 | guards-ssot | sources-inventory | EFHC_Bot_v149_20 | [md](docs/audits/2026-03-01_guards-ssot_v149_20__audit_sources_inventory.md) | Закрепляет хранение первичных источников аудита в _raw и обязательную связку evidence через audits_index.json. |
| AUD-2026-02-28-ROUTES-INVENTORY-001 | 2026-02-28 | routes-inventory | routes-inventory@api | EFHC_Bot_v149_14 | [md](docs/audits/2026-02-28_routes-inventory_v149_14__backend_routes.md) | Свод: обнаружено 87 маршрутов; сгруппированы admin/user/cron. |
| AUD-2026-02-28-ROUTES-INVENTORY-002 | 2026-02-28 | routes-inventory | routes-inventory@registry | EFHC_Bot_v149_16_add_registry_audits | [md](docs/audits/2026-02-28_routes-inventory_v149_16__routes_reg.md) | Реестр маршрутов: method, path, handler, file:line. |
| AUD-2026-02-28-ROUTES-INVENTORY-003 | 2026-02-28 | routes-inventory | routes-inventory@route-table-map | EFHC_Bot_v149_17 | [md](docs/audits/2026-02-28_routes-inventory_v149_17__route_table_map.md) | Карта маршруты→сервисы→таблицы; отмечены P0 DYNAMIC_SQL в /ranks. |


## SUPERSEDED

| Audit-Id | Date | Topic | Scope-Key | Version | File | Summary |
|---|---|---|---|---|---|---|
| AUD-2026-02-28-DB-INVENTORY-001 | 2026-02-28 | db-inventory | db-inventory@core-admin | EFHC_Bot_v149_14 | [md](docs/audits/2026-02-28_db-inventory_v149_14__core_admin_inventory.md) | Свод: ORM 30 имён, 0001 создаёт 20, sanity 2/8, routes 87. |
| AUD-2026-02-28-GUARDS-SSOT-001 | 2026-02-28 | guards-ssot | guards-ssot@bans | EFHC_Bot_v149_14 | [md](docs/audits/2026-02-28_guards-ssot_v149_14__bans_and_zip_hygiene.md) | Свод: запреты telegram-id/rank/tg_id/user-key; контроль мусора в ZIP. |


## ARCHIVED

_None._


## Topics dictionary

- `db-inventory`
- `db-ssot`
- `routes-inventory`
- `admin-surface`
- `ci-failures`
- `guards-ssot`
- `security`
- `performance`
- `data-migration`

## How to add a new audit

1. Create md file in docs/audits/ with canonical name:
YYYY-MM-DD_<topic>_v<repo_version>__<short_slug>.md
2. Fill SSOT header + required sections + Evidence Index.
3. Add entry to audits_index.json.
4. Run:
- python ops/audits_index_lint.py
- python ops/audits_md_lint.py
5. Regenerate this README:
- python ops/audits_readme_generate.py
