# SSOT_REFACTOR_PLAN

## P0
- Goal: Eliminate name/schema drift between ORM, migrations, and
  raw SQL.
- Files: backend/migrations/versions/0001_init.py; backend/app/models/*;
  backend/app/services/admin/*; backend/app/deps.py.
- Migrations: revise 0001 in-place (no 0002+) per user rule.
- Data risk: HIGH (table renames / missing tables) — require evidence.
- Verify: alembic upgrade head; sanity to_regclass(); pytest.

Checklist:
- [ ] Choose SSOT table dictionary (ORM-first vs migration-first).
- [ ] Ensure `DB_SCHEMA_ADMIN` exists in core config and remove
      fallback literals.
- [ ] Resolve admin external tables list (see
      SSOT_DUPLICATES_AND_ADMIN_EXTERNAL.md).
- [ ] Fix any forbidden `schema=` inside `sa.Column(...)` in 0001.

## P1
- Goal: Route→table map completeness and reduce dynamic SQL.
- Files: backend/app/routes/*; backend/app/services/*.
- Data risk: MEDIUM.
- Verify: add route-level tests where feasible.

Checklist:
- [ ] Replace `{SCHEMA_*}.table` dynamic SQL with SQLAlchemy or fixed
      schema-qualified constants.
- [ ] Expand route-table evidence mapping in SSOT_ROUTE_TABLE_MAP.csv.

## P2
- Goal: Documentation and automation hardening.
- Files: docs/audits/*; ops/*; .github/workflows/*.
- Data risk: LOW.
- Verify: CI lint passes; README generation stable.

Checklist:
- [ ] Keep audits_index.json and README in sync via generator.
- [ ] Enforce zip content guard (no missing files; no pycache).