# EFHC SSOT: Механика Обменника и Вывода

## 0) Статус документа

Этот документ является SSOT для механики:

- EXCHANGE_ALL (обмен kWh → EFHC MAIN)
- WITHDRAW (вывод из EFHC MAIN)

Все реализации (backend/frontend/tests/audit) обязаны
соответствовать этому документу.
Любое расхождение считается дефектом.

---

## 1) Канон и запреты (MUST)

### 1.1 Идентификаторы

- MUST: идентификатор пользователя — только `tg_id` (snake_case).
- MUST NOT: любые альтернативные имена идентификатора пользователя
  (например: `telegram id`, `tg-id (camelCase)`, `tg_id` и т.п.).

### 1.2 Запрещённые подстроки

- MUST NOT: семейство подстрок вида `r·ating`
  (в любом виде, включая части слов/путей/тестов/доков).

### 1.3 Денежная точность

- MUST: Decimal scale = 8.
- MUST: округление DOWN.
- MUST NOT: float/Number/toFixed/scientific notation
  в финансовых расчётах и логах.

### 1.4 Запрет списания lifetime

- MUST: `total_generated_kwh` append-only (только растёт).
- MUST NOT: уменьшать `total_generated_kwh` при любых операциях
  (обмен/вывод/покупки/что угодно).

---

## 2) Термины и величины (SSOT)

### 2.1 Lifetime генерация

`total_generated_kwh` — общий накопленный объём генерации
kWh за всё время.

Инвариант: `total_generated_kwh(t+Δ) >= total_generated_kwh(t)`.

### 2.2 «Минус обмен» (накопительно)

`exchanged_kwh_total` — сколько kWh было обменено за всё время.

Инвариант: `exchanged_kwh_total(t+Δ) >= exchanged_kwh_total(t)`.

### 2.3 Зеркальная ветка (доступно к обмену)

`available_kwh` — доступный остаток к обмену, **не хранится** как
«списываемый баланс», а вычисляется зеркалом.

Формула (MUST):

`available_kwh = max(total_generated_kwh - exchanged_kwh_total, 0)`

Запрет (MUST NOT):

Прямое «списание available_kwh» (например `available_kwh -= ...`)
запрещено как нарушение SSOT.

### 2.4 Денежная ветка MAIN

`main_balance` — EFHC MAIN, единственный источник вывода.

Финансовая чистота (канон):

- Входящие EFHC за TON/USDT (deposit_efhc, shop_external)
  начисляются в `main_balance`.
- `bonus_balance` не используется для вывода.

BONUS в обменнике:

- MUST NOT: отображаться
- MUST NOT: участвовать в обмене
- MUST NOT: участвовать в выводе

---

## 3) Экономика обмена (канон)

### 3.1 Курс (MUST)

`1 kWh = 1 EFHC` (фиксированный курс).

`amount_efhc = amount_kwh` (строго 1:1).

### 3.2 Эквивалент (инвариант сохранения)

Определим:

`total_equivalent = main_balance + available_kwh`

Инвариант обмена (MUST):

После EXCHANGE_ALL: `total_equivalent_after == total_equivalent_before`.

Банк EFHC (внутренний контрагент):

- EXCHANGE_ALL начисляет пользователю EFHC MAIN проводкой
  `user credit ⇒ bank debit`.
- Банк может уходить в минус.
  Дефицит допустим и покрывается внешним обеспечением.

---

## 4) Операция EXCHANGE_ALL (Обмен)

### 4.1 Назначение

EXCHANGE_ALL переносит **всю** доступную зеркальную энергию в EFHC MAIN.

### 4.2 Сумма обмена (MUST)

`amount_kwh = available_kwh` (на момент выполнения операции).

Если `available_kwh <= 0.00000000` → операция запрещена
(no-op/rejected).

### 4.3 Атомарная механика (MUST)

Операция выполняется в **одной транзакции** с блокировкой строки
пользователя (`FOR UPDATE`) или эквивалентной атомарностью.

Снимок ДО (before):

- `tg_id`
- `total_generated_kwh_before`
- `exchanged_kwh_total_before`
- `available_kwh_before` (derived)
- `main_balance_before`

Расчёт:

- `amount_kwh = available_kwh_before`
- `amount_efhc = amount_kwh` (1:1)

Снимок ПОСЛЕ (after), success:

- `exchanged_kwh_total_after = exchanged_kwh_total_before + amount_kwh`
- `available_kwh_after = max(
    total_generated_kwh_before - exchanged_kwh_total_after, 0
  )` (ожидаемо 0)
- `main_balance_after = main_balance_before + amount_efhc`
- `total_generated_kwh_after == total_generated_kwh_before` (MUST)

### 4.4 Запреты (MUST NOT)

- MUST NOT: уменьшать `total_generated_kwh`.
- MUST NOT: прямое списание `available_kwh` как хранимого баланса.
- MUST NOT: начислять в BONUS.
- MUST NOT: изменять курс (только 1:1).
- MUST NOT: выполнять частичный обмен в рамках EXCHANGE_ALL.

---

## 5) Операция WITHDRAW (Вывод)

### 5.1 Источник (MUST)

Вывод возможен только из `main_balance`.

### 5.2 Сумма (MUST)

Пользователь выбирает `amount` вручную.

Валидация (MUST):

- `amount >= 10.00000000`
- `amount <= main_balance`

Кнопка MAX в UI:

`amount = main_balance`

### 5.3 Атомарность (MUST)

WITHDRAW должна быть защищена от гонок:

- либо `FOR UPDATE` по строке пользователя/балансу,
- либо атомарный `UPDATE ... WHERE main_balance >= amount` + проверка
  rowcount,
- и обязательно Idempotency-Key (см. ниже).

Проводки (канон):

- Создание заявки на вывод делает внутреннюю проводку
  `user debit ⇒ bank credit` на `amount_d8`.
- Внешняя выплата в TON-сети не меняет внутренние балансы повторно.

---

## 6) Идемпотентность (MUST)

### 6.1 Где применяется

- EXCHANGE_ALL — MUST use Idempotency-Key.
- WITHDRAW — MUST use Idempotency-Key.
  Дополнительно: WalletGate (wallet_connected) обязателен,
  см. docs/WALLETS_TONCONNECT_SSOT.md.

### 6.2 Правило

Повтор запроса с тем же Idempotency-Key:

- MUST NOT: выполнять операцию второй раз
- MUST: возвращать тот же результат/статус
- MUST: фиксироваться как повторный вызов (replay) в аудите

---

## 7) Аудит-лог (MUST, «было/стало»)

Аудит обязателен для:

success / rejected / error / replay.

### 7.1 Формат audit.extra_info для EXCHANGE_ALL (MUST)

before:

- `total_generated_kwh_before`
- `exchanged_kwh_total_before`
- `available_kwh_before` (derived)
- `main_balance_before`
- `withdrawable_main_before = main_balance_before`
- `total_equivalent_before = main_balance_before + available_kwh_before`

after (всегда заполнять, даже rejected/error):

- `total_generated_kwh_after`
- `exchanged_kwh_total_after`
- `available_kwh_after` (derived)
- `main_balance_after`
- `withdrawable_main_after`
- `total_equivalent_after`

инвариант:

`invariant_ok` (bool) =
(`total_equivalent_after == total_equivalent_before` и
`total_generated_kwh_after == total_generated_kwh_before`).

### 7.2 Формат audit.extra_info для WITHDRAW (MUST)

before/after:

- `main_balance_before`
- `main_balance_after` (если списание мгновенное; если
  заявка — фиксируем статус и ожидаемое)
- `amount`
- `min_amount = 10.00000000`
- `invariant_ok` (например `main_balance_after <= main_balance_before`
  при success)

---

## 8) UI-правила Обменника (референс)

Экран «Обменник» состоит из двух окон:

Верхнее окно: Обмен

- Показывает `available_kwh` (derived) форматом `0.00000000`.
- Текст: «Курс: 1 kWh = 1 EFHC».
- Одна кнопка: «Обмен» (EXCHANGE_ALL).
- Disabled если `available_kwh <= 0.00000000`.

Нижнее окно: Вывод

- Показывает `main_balance` форматом `0.00000000`.
- Поле Amount + кнопки рядом MAX и «Вывод».
- Валидация: `10.00000000 <= amount <= main_balance`.
- BONUS не отображается нигде.

---

## 9) Обязательные тесты (MUST)

### 9.1 Append-only lifetime

Тест, что EXCHANGE_ALL и WITHDRAW никогда не уменьшают
`total_generated_kwh`.

### 9.2 Mirror-only доступность

Тест/статический контроль, что нет прямого «debit available_kwh».

Тест, что `available_kwh` вычисляется как
`max(total_generated_kwh - exchanged_kwh_total, 0)`.

### 9.3 Concurrency (SHOULD → лучше MUST)

- Два параллельных EXCHANGE_ALL (разные Idempotency-Key) →
  начисление MAIN один раз.
- EXCHANGE_ALL + WITHDRAW параллельно → консистентность `main_balance` и
  `exchanged_kwh_total`.
- Два параллельных WITHDRAW → нет двойного списания/перерасхода.

---

## 10) БД-инварианты (SHOULD, желательно как CHECK)

- `exchanged_kwh_total >= 0`
- `total_generated_kwh >= 0`
- `exchanged_kwh_total <= total_generated_kwh`

---

## 11) Запреты прямых мутаций (MUST)

- Запрещены любые паттерны уменьшения `total_generated_kwh`.
- Запрещены любые паттерны прямого уменьшения `available_kwh`.
- Единственный допустимый путь «минус обмен» —
  рост `exchanged_kwh_total`.

### Канон внешнего входа EFHC

- Любое внешнее пополнение EFHC jetton или покупка EFHC за TON/USDT
  в сети
  TON зачисляются пользователю **только в EFHC_MAIN**.
- Внутренний перевод: **user credit ⇒ bank debit** (bank main).

### Канон вывода

- Вывод возможен **только и только из EFHC_MAIN** пользователя.
- EFHC_BONUS не выводится; может тратиться на всё остальное.
