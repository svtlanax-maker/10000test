# Telegram WebApp integration (EFHC SSOT)

## Цели

1) Каноничный UX в Telegram WebApp
   без влияния на SSOT.
2) Идентичность пользователя
   подтверждается только через initData.
3) Запрет хранения финансовых данных
   на клиенте.

## Frontend (канон)

### Safe-access слой

Единый модуль: `frontend/src/lib/telegram.ts`.

Обязательные правила:

- Доступ к `window.Telegram`
  только через helper `tg()`.
- `tgReady()` вызывается один раз
  при старте приложения.
- Интеграция не должна затрагивать
  расчёты D8/SSOT.

### Theme sync

- Цвета/параметры Telegram
  применяются только как CSS vars.
- Нельзя менять SSOT числа
  при синхронизации темы.

### Telegram Theme Tokens (канон)

Контракт визуальной темы EFHC WebApp фиксируется через
единый
набор CSS tokens.
Компоненты SSOT-зоны используют только
эти переменные, без хардкода цветов.

Обязательные tokens (MUST):

- `--tg-bg`
- `--tg-text`
- `--tg-hint`
- `--tg-link`
- `--tg-button`
- `--tg-button-text`
- `--tg-secondary-bg`

Маппинг из `Telegram.WebApp.themeParams`:

- `bg_color` -> `--tg-bg`
- `text_color` -> `--tg-text`
- `hint_color` -> `--tg-hint`
- `link_color` -> `--tg-link`
- `button_color` -> `--tg-button`
- `button_text_color` -> `--tg-button-text`
- `secondary_bg_color` -> `--tg-secondary-bg`

Fallback правила:

- Если `secondary_bg_color` отсутствует,
  использовать `bg_color`.
- Если отдельный параметр отсутствует,
  оставить дефолт token из `globals.css`.
- Никаких преобразований D8/балансов:
  только UI.

### Haptics

- Допускается только на UI-события:
  - tap
  - success / error
- Запрещено привязывать haptics к расчётам
  балансов.

### MainButton / BackButton

- BackButton показывается только на
  подэкранах/модалках.
- На корневых вкладках BackButton скрыт.
- MainButton — UI-триггер.
  Все балансы/решения берутся с backend.

### CloudStorage (жёсткий запрет для финансов)

Разрешено хранить только UI-настройки,
например:

- выбранная вкладка
- фильтр
- локальные UI переключатели

Запрещено хранить (MUST NOT):

- balance / main_balance
- available / available_kwh
- withdraw / exchange значения и статусы
- права, VIP/NFT, результаты операций

## Backend (канон)

### initData verification

- Подпись initData валидируется на сервере
  (HMAC по Telegram).
- `tg_id` извлекается только из
  валидированного initData (или серверной
  сессии), не из клиента.

## Guards / Tests

- UI SSOT guard валит CI при `Number(`
  / `parseFloat(` / `toFixed(`
  / `toExponential(` в фиксированных SSOT UI путях.
- CloudStorage guard валит CI при попытке
  использовать ключи financial/state-типа
  (`balance`, `withdraw`, `exchange` и т.п.).
