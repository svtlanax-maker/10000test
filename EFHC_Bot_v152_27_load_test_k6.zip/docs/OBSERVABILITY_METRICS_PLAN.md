# OBSERVABILITY METRICS PLAN

Следующий слой наблюдаемости для self-healing и фоновых процессов.

## Минимальные метрики

- count фоновых ошибок по имени задачи
- duration критических фоновых циклов
- count enqueue / retry / soft-fallback
- count rebuild snapshot / resync / backfill
- count admin critical actions

## Приоритетные контуры

- scheduler
- sync
- TON inbox watcher
- ranks snapshot rebuild
- admin bank / withdraw / lotteries

Пока это зафиксировано как план и стандарт наблюдаемости.
