# EFHC Bot — схема и зависимости (RU, SSOT)

## 1. Репозиторий: верхний уровень

- backend/  — FastAPI backend, модели, сервисы, scheduler.
- frontend/ — Next.js WebApp (пользователь + admin).
- api/      — вспомогательные файлы (инфраструктура/деплой).
- ops/      — канон-guard, cleanup артефактов, операции упаковки.
- tests/    — тесты канона и регрессии.
- docs/     — внутренняя SSOT-документация.

## 2. Backend: ключевые подсистемы

- backend/app/routes/      — HTTP роуты (FastAPI).
- backend/app/services/    — бизнес-логика по доменам.
- backend/app/models/      — SQLAlchemy модели.
- backend/app/schemas/     — Pydantic схемы.
- backend/app/database.py  — подключение к БД и сессии.
- backend/app/deps.py      — зависимости FastAPI (auth/admin/idempo).
- backend/app/integrations/ — внешние интеграции (TON API и др.).
- backend/app/scheduler/   — фоновые задачи.
- backend/migrations/      — Alembic миграции.

## 3. Frontend: ключевые подсистемы

- frontend/src/pages/      — страницы WebApp и admin.
- frontend/src/components/ — UI компоненты.
- frontend/src/lib/        — клиент API, утилиты.
- frontend/src/hooks/      — React hooks.

## 4. Внешние зависимости и сервисы

Runtime (прод):
- Python 3.x, FastAPI, Uvicorn/ASGI.
- SQLAlchemy (async), asyncpg, Alembic.
- PostgreSQL (основное хранилище).
- Telegram Bot API и Telegram WebApp initData.
- TON: получение событий/транзакций, обработка memo и зачисления.

Dev/Test:
- pytest (запуск тестов).
- ruff (только проверка импортов: E402/E401/F403/F405).
- freezegun (заморозка времени в тестах).

## 5. Зависимости между слоями

- routes → services → models/schemas → database
- scheduler/watchers → services → database → transactions/bank
- frontend → backend HTTP API (через tg initData)

Критичное:
- Внутренний идентификатор пользователя во всех доменах: tg_id.
- Идемпотентность критичных операций: списания/начисления/выплаты.
- Логи и аудит: admin logs, операции банка, выводы, розыгрыши.

## 6. Где смотреть точные списки

- docs/dependency_map.md — список pip и зачем они нужны.
- requirements.txt, requirements-dev.txt, requirements-test.txt
- package.json (frontend зависимости)
