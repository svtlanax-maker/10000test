# Каталог тестов EFHC Bot (SSOT)

Источник истины: реальные файлы `tests/**/test_*.py`.

Актуальный срез:
- test files: **73**
- architecture: **23**
- core: **3**
- efhc_backend/unit: **12**
- frontend: **0**
- root/integration: **35**

Правило (MUST): каталог обновляется строго по реальному `tests/**`.

A) Architecture

1. `tests/architecture/test_admin_routes_guarded.py`
   Архитектурный guard и репозиторный stop-кран.

2. `tests/architecture/test_api_finance_canon.py`
   Архитектурный guard и репозиторный stop-кран.

3. `tests/architecture/test_bank_runtime_invariants.py`
   Архитектурный guard и репозиторный stop-кран.

4. `tests/architecture/test_deposit_packages_contract.py`
   Архитектурный guard и репозиторный stop-кран.

5. `tests/architecture/test_docs_ssot_sync.py`
   Архитектурный guard и репозиторный stop-кран.

6. `tests/architecture/test_exchange_mirror_and_locks.py`
   Архитектурный guard и репозиторный stop-кран.

7. `tests/architecture/test_financial_integrity.py`
   Архитектурный guard и репозиторный stop-кран.

8. `tests/architecture/test_forbidden_identifiers_repo.py`
   Архитектурный guard и репозиторный stop-кран.

9. `tests/architecture/test_frontend_tabs_canon.py`
   Архитектурный guard и репозиторный stop-кран.

10. `tests/architecture/test_great_canon_guard.py`
   Архитектурный guard и репозиторный stop-кран.

11. `tests/architecture/test_max_line_length_72.py`
   Архитектурный guard и репозиторный stop-кран.

12. `tests/architecture/test_migrations_numbering_canon.py`
   Архитектурный guard и репозиторный stop-кран.

13. `tests/architecture/test_no_available_kwh_direct_debit.py`
   Архитектурный guard и репозиторный stop-кран.

14. `tests/architecture/test_no_backend_app_imports_repo.py`
   Архитектурный guard и репозиторный stop-кран.

15. `tests/architecture/test_no_banned_rank_terms.py`
   Архитектурный guard и репозиторный stop-кран.

16. `tests/architecture/test_no_raw_create_task.py`
   Архитектурный guard и репозиторный stop-кран.

17. `tests/architecture/test_no_tg_id_aliases_repo.py`
   Архитектурный guard и репозиторный stop-кран.

18. `tests/architecture/test_no_total_generated_kwh_decrement.py`
   Архитектурный guard и репозиторный stop-кран.

19. `tests/architecture/test_panels_no_local_numeric_casts.py`
   Архитектурный guard и репозиторный stop-кран.

20. `tests/architecture/test_repo_file_integrity_manifest.py`
   Архитектурный guard и репозиторный stop-кран.

21. `tests/architecture/test_route_idempotency_policy.py`
   Архитектурный guard и репозиторный stop-кран.

22. `tests/architecture/test_withdraw_admin_contract.py`
   Архитектурный guard и репозиторный stop-кран.

23. `tests/architecture/test_withdraw_runtime_invariants.py`
   Архитектурный guard и репозиторный stop-кран.

B) Core

1. `tests/core/test_async_tasks.py`
   Runtime-проверки helper `create_logged_task()`.

2. `tests/core/test_core_math_econ.py`
   Ядро математики и middleware.

3. `tests/core/test_monetary_idempotency_middleware.py`
   Ядро математики и middleware.

C) EFHC backend

1. `tests/efhc_backend/unit/test_cursor_codec_ssot.py`
   Юнит- и контрактные проверки доменов EFHC.

2. `tests/efhc_backend/unit/test_exchange.py`
   Юнит- и контрактные проверки доменов EFHC.

3. `tests/efhc_backend/unit/test_finance_spend_rules.py`
   Юнит- и контрактные проверки доменов EFHC.

4. `tests/efhc_backend/unit/test_no_legacy_words.py`
   Юнит- и контрактные проверки доменов EFHC.

5. `tests/efhc_backend/unit/test_orders.py`
   Юнит- и контрактные проверки доменов EFHC.

6. `tests/efhc_backend/unit/test_prizes_autocycle_ssot.py`
   Юнит- и контрактные проверки доменов EFHC.

7. `tests/efhc_backend/unit/test_prizes_smoke.py`
   Юнит- и контрактные проверки доменов EFHC.

8. `tests/efhc_backend/unit/test_shop_items.py`
   Юнит- и контрактные проверки доменов EFHC.

9. `tests/efhc_backend/unit/test_ssot_idempotency.py`
   Юнит- и контрактные проверки доменов EFHC.

10. `tests/efhc_backend/unit/test_ssot_tg_only.py`
   Юнит- и контрактные проверки доменов EFHC.

11. `tests/efhc_backend/unit/test_telegram_init_data.py`
   Юнит- и контрактные проверки доменов EFHC.

12. `tests/efhc_backend/unit/test_transactions.py`
   Юнит- и контрактные проверки доменов EFHC.

D) Frontend

1. _Нет файлов в текущем срезе._

F) Root integration

1. `tests/test_alembic_healthcheck_soft.py`
   Интеграционные, миграционные и доменные тесты.

2. `tests/test_build_sanity.py`
   Интеграционные, миграционные и доменные тесты.

3. `tests/test_canon_guard_negative.py`
   Интеграционные, миграционные и доменные тесты.

4. `tests/test_concurrency_exchange_all.py`
   Интеграционные, миграционные и доменные тесты.

5. `tests/test_concurrency_exchange_withdraw.py`
   Интеграционные, миграционные и доменные тесты.

6. `tests/test_concurrency_withdraw_double.py`
   Интеграционные, миграционные и доменные тесты.

7. `tests/test_economics_transactions.py`
   Интеграционные, миграционные и доменные тесты.

8. `tests/test_exchange_audit_fields_complete.py`
   Интеграционные, миграционные и доменные тесты.

9. `tests/test_frontend_telegram_api_guard.py`
   Интеграционные, миграционные и доменные тесты.

10. `tests/test_gen_rate_vip_switch.py`
   Интеграционные, миграционные и доменные тесты.

11. `tests/test_migrations_upgrade_head.py`
   Интеграционные, миграционные и доменные тесты.

12. `tests/test_no_banned_identifiers.py`
   Интеграционные, миграционные и доменные тесты.

13. `tests/test_no_banned_lotteries_terms.py`
   Интеграционные, миграционные и доменные тесты.

14. `tests/test_no_placeholders.py`
   Интеграционные, миграционные и доменные тесты.

15. `tests/test_panels_180_days.py`
   Интеграционные, миграционные и доменные тесты.

16. `tests/test_panels_active_archive.py`
   Интеграционные, миграционные и доменные тесты.

17. `tests/test_panels_global_id.py`
   Интеграционные, миграционные и доменные тесты.

18. `tests/test_panels_idempotent_create.py`
   Интеграционные, миграционные и доменные тесты.

19. `tests/test_panels_ssot_backend.py`
   Интеграционные, миграционные и доменные тесты.

20. `tests/test_panels_uses_canon_formatter.py`
   Интеграционные, миграционные и доменные тесты.

21. `tests/test_payment_intent_status_owner_only.py`
   Интеграционные, миграционные и доменные тесты.

22. `tests/test_payment_intents_ab_ssot.py`
   Интеграционные, миграционные и доменные тесты.

23. `tests/test_payment_intents_lifecycle_double_payments.py`
   Интеграционные, миграционные и доменные тесты.

24. `tests/test_payment_intents_payload_unique.py`
   Интеграционные, миграционные и доменные тесты.

25. `tests/test_payment_intents_usdt_tx_and_confirm.py`
   Интеграционные, миграционные и доменные тесты.

26. `tests/test_per_sec_constants_settings.py`
   Интеграционные, миграционные и доменные тесты.

27. `tests/test_per_sec_literals_guard.py`
   Интеграционные, миграционные и доменные тесты.

28. `tests/test_tonconnect_wallets_ssot.py`
   Интеграционные, миграционные и доменные тесты.

29. `tests/test_total_generated_kwh_append_only.py`
   Интеграционные, миграционные и доменные тесты.

30. `tests/test_ui_ssot_no_float_number.py`
   Интеграционные, миграционные и доменные тесты.

31. `tests/test_unmatched_incoming_recording.py`
   Интеграционные, миграционные и доменные тесты.

32. `tests/test_utcnow_ssot.py`
   Интеграционные, миграционные и доменные тесты.

33. `tests/test_wallets_connect_hardening.py`
   Интеграционные, миграционные и доменные тесты.

34. `tests/test_wallets_tonconnect_semantics_guard.py`
   Интеграционные, миграционные и доменные тесты.

35. `tests/test_withdraw_state_machine.py`
   Интеграционные, миграционные и доменные тесты.
