# EFHC Bot — страницы, разделы, достижения (RU, SSOT)

## 1. Пользовательские страницы WebApp

Файлы: frontend/src/pages/*.tsx

- index.tsx     — главная/дашборд пользователя.
- panels.tsx    — панели и генерация энергии.
- shop.tsx      — магазин (покупки внутри проекта).
- tasks.tsx     — задания и прогресс.
- lotteries.tsx — призовые события и победители (страница витрины).
- referrals.tsx — реферальная система.
- ranks.tsx    — рейтинг и достижения.
- exchange.tsx  — обмен/конвертация внутри правил проекта.
- ads.tsx       — реклама/офферы (если включено).

## 2. Админ-панель WebApp

Файлы: frontend/src/pages/admin/*.tsx

- admin/index.tsx        — админ-дашборд.
- admin/users.tsx        — пользователи, статусы, балансы.
- admin/bank.tsx         — банк EFHC, централизованный баланс.
- admin/withdrawals.tsx  — выводы EFHC, очереди, приоритеты.
- admin/panels.tsx       — панели (продажи, выдача, аудит).
- admin/shop.tsx         — Shop операции и подтверждения.
- admin/prizes.tsx       — призовые события: история и победители.
- admin/tasks.tsx        — задачи (создание/публикация/архив).
- admin/referrals.tsx    — реферальные начисления и аудит.
- admin/ads.tsx          — рекламные блоки.
- admin/logs.tsx         — логи операций и фильтры.
- admin/reports.tsx      — отчёты/сводки.

## 3. Шкала достижений (12 уровней)

Названия уровней (канон):

1) Eco Initiate
2) Hope Bringer
3) Energy Seeker
4) Nature's Voice
5) Earth Ally
6) Climate Fighter
7) Green Sentinel
8) Planet Defender
9) Eco Champion
10) Planet Saver
11) Green Commander
12) Guardian of Earth

Использование:
- Рейтинг строится по total_generated_kwh.
- Уровень определяется функцией get_rank_level(total_generated_kwh).
- В выдаче рейтинга пользователь идёт первым, затем топ-100.

## 4. События и домены (крупными блоками)

- transactions/банк: начисления, списания, покупка панелей, Shop.
- energy: генерация kWh, пересчёты, хранение total_generated_kwh.
- prizes/lotteries: призовые события и выдача призов.
- tasks: задания и прогресс.
- referrals: реферальные связи и бонусы.
- watchers/scheduler: TON inbox, периодические джобы.
- admin: ручки админки, логи, отчёты.

Подробности по правилам см. в docs/*_RULES.md.


## Глобальный хедер (WebApp)

Хедер закреплён сверху (sticky) и виден на всех 6 вкладках.

Показывает:
- аватар (клик → Profile/Settings),
- username и LVL,
- общий баланс Total = main_balance + bonus_balance,
- кнопки + и Shop.

В хедере не отображаются отдельные строки MAIN/BONUS.

## Нижняя навигация (Bottom Nav)

Ровно 6 вкладок, фиксированный порядок:
Energy | Panels | Exchange | Tasks | Referrals | Ranks.

Активная вкладка подсвечивается по пути:
/, /panels, /exchange, /tasks, /referrals, /ranks.

## Energy: прогресс 12 уровней (T2)

Energy отображает:
- "живое" E(t) от server_now_iso и gen_per_sec_effective,
- шкалу 12 уровней с порогами kWh,
- LVL N/12 и название уровня под прогресс-баром.
